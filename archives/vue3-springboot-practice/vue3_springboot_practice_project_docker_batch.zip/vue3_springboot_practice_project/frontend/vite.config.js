import { fileURLToPath, URL } from "node:url";

import vue from "@vitejs/plugin-vue";
import { defineConfig } from "vite";

const backendUrl = process.env.VITE_BACKEND_URL || "http://localhost:8080";
const websocketUrl = backendUrl.replace(/^http/, "ws");

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: backendUrl,
        changeOrigin: true
      },
      "/ws": {
        target: websocketUrl,
        ws: true
      }
    }
  },
  build: {
    outDir: fileURLToPath(
      new URL("../backend/src/main/resources/static", import.meta.url)
    ),
    emptyOutDir: true
  }
});
