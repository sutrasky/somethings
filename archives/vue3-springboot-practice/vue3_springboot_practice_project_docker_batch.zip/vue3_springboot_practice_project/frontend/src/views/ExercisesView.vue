<script setup>
import { computed, onMounted, reactive, watch } from "vue";

const STORAGE_KEY = "student-practice-checklist";

const exercises = [
  {
    id: "persistence",
    tag: "MySQL",
    title: "练习 1：验证 MySQL 持久化",
    description:
      "新增一名学生，执行 docker compose down，再执行 docker compose up -d，重启 Spring Boot，确认学生仍然存在。",
    expected: "数据来自项目根目录 data/ 下持久化的 MySQL 文件。"
  },
  {
    id: "complex-object",
    tag: "DTO",
    title: "练习 2：提交复杂对象",
    description:
      "新增学生时填写地址，并添加至少两门课程。打开学生详情页，检查地址对象和课程数组。",
    expected: "POST /api/students 的 JSON 同时包含 address 和 courses。"
  },
  {
    id: "validation",
    tag: "Validation",
    title: "练习 3：观察嵌套校验",
    description:
      "把城市留空，把课程成绩写为 101，提交表单并查看字段错误。",
    expected: "后端返回 400，错误键包含 address.city 和 courses[0].score。"
  },
  {
    id: "search-update",
    tag: "CRUD",
    title: "练习 4：搜索、编辑、删除",
    description:
      "在学生列表搜索姓名，进入详情页编辑课程成绩，再删除一名测试学生。",
    expected: "完整走通 GET、PUT、DELETE 三种 REST 请求。"
  },
  {
    id: "messaging",
    tag: "STOMP",
    title: "练习 5：观察消息通信",
    description:
      "打开两个消息中心标签页，从 STOMP 发送消息，然后等待 20 秒观察 @Scheduled 推送。",
    expected: "两个标签页都会收到用户消息和每 10 秒一次的系统定时消息。"
  },
  {
    id: "batch",
    tag: "Batch",
    title: "练习 6：运行 Spring Batch",
    description:
      "打开 Batch 页面，连续点击两次“启动导入 Job”，观察 CSV 读取、校验、MySQL 写入和去重。",
    expected:
      "首次读取并写入 3 条学生，第二次仍读取 3 条但学生总数不重复增加。"
  }
];

const checked = reactive({});

const completedCount = computed(
  () => exercises.filter((exercise) => checked[exercise.id]).length
);

const progress = computed(() =>
  Math.round((completedCount.value / exercises.length) * 100)
);

onMounted(() => {
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  for (const exercise of exercises) {
    checked[exercise.id] = Boolean(saved[exercise.id]);
  }
});

watch(
  checked,
  (value) => localStorage.setItem(STORAGE_KEY, JSON.stringify(value)),
  { deep: true }
);
</script>

<template>
  <section>
    <div class="hero-panel exercise-hero">
      <div>
        <p class="eyebrow">HANDS-ON CHECKLIST</p>
        <h1>完整动手练习</h1>
        <p>
          从 MySQL 持久化到复杂对象、REST CRUD、STOMP 和 Spring Batch，
          每完成一道就在浏览器中标记。
        </p>
      </div>
      <div class="progress-ring">
        <strong>{{ progress }}%</strong>
        <span>{{ completedCount }}/{{ exercises.length }}</span>
      </div>
    </div>

    <div class="progress-bar-wide">
      <i :style="{ width: `${progress}%` }"></i>
    </div>

    <div class="exercise-list">
      <article
        v-for="(exercise, index) in exercises"
        :key="exercise.id"
        class="exercise-card"
        :class="{ completed: checked[exercise.id] }"
      >
        <label>
          <input v-model="checked[exercise.id]" type="checkbox" />
          <span class="custom-check"></span>
        </label>
        <div class="exercise-number">{{ String(index + 1).padStart(2, "0") }}</div>
        <div class="exercise-content">
          <span class="concept-tag">{{ exercise.tag }}</span>
          <h2>{{ exercise.title }}</h2>
          <p>{{ exercise.description }}</p>
          <div class="expected-box">
            <strong>预期结果</strong>
            <span>{{ exercise.expected }}</span>
          </div>
        </div>
      </article>
    </div>
  </section>
</template>
