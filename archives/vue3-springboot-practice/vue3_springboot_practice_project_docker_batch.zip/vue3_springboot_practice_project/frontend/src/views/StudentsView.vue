<script setup>
import { computed, onMounted, ref } from "vue";
import { RouterLink } from "vue-router";

import { ApiError, getStudents } from "../api/client";
import { useNotifications } from "../composables/useNotifications";
import { averageScore, formatDateTime } from "../utils/format";

const { messages } = useNotifications();
const students = ref([]);
const query = ref("");
const loading = ref(true);
const errorMessage = ref("");

const averageAge = computed(() => {
  if (!students.value.length) {
    return 0;
  }
  return Math.round(
    students.value.reduce((sum, student) => sum + student.age, 0) /
      students.value.length
  );
});

async function loadStudents() {
  loading.value = true;
  errorMessage.value = "";
  try {
    students.value = await getStudents(query.value);
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError ? error.message : `加载失败：${error.message}`;
  } finally {
    loading.value = false;
  }
}

function clearSearch() {
  query.value = "";
  loadStudents();
}

onMounted(loadStudents);
</script>

<template>
  <section>
    <div class="hero-panel">
      <div>
        <p class="eyebrow">STUDENT MANAGEMENT</p>
        <h1>学生资料与复杂对象练习</h1>
        <p>
          学生对象包含地址和课程列表。数据保存在 Docker MySQL，
          页面由 Vue Router 管理，并持续接收 Spring Messaging 通知。
        </p>
      </div>
      <RouterLink class="primary-button" to="/students/new">
        新增学生 <span>＋</span>
      </RouterLink>
    </div>

    <div class="stats-grid">
      <article>
        <span>学生总数</span>
        <strong>{{ students.length }}</strong>
        <small>MySQL / students</small>
      </article>
      <article>
        <span>平均年龄</span>
        <strong>{{ averageAge }}</strong>
        <small>后端字段统计</small>
      </article>
      <article>
        <span>STOMP 消息</span>
        <strong>{{ messages.length }}</strong>
        <small>当前页面会话</small>
      </article>
    </div>

    <div class="toolbar-card">
      <form class="search-form" @submit.prevent="loadStudents">
        <label for="student-search">按姓名搜索</label>
        <div class="inline-input">
          <input
            id="student-search"
            v-model.trim="query"
            type="search"
            placeholder="例如：张"
          />
          <button class="secondary-button" type="submit">搜索</button>
          <button
            v-if="query"
            class="ghost-button"
            type="button"
            @click="clearSearch"
          >
            清除
          </button>
        </div>
      </form>
      <span class="counter">{{ students.length }} 条记录</span>
    </div>

    <div v-if="errorMessage" class="alert alert-error">{{ errorMessage }}</div>
    <div v-if="loading" class="loading-card">正在从 MySQL 加载学生……</div>

    <div v-else-if="students.length === 0" class="empty-card">
      <h2>没有找到学生</h2>
      <p>可以清除搜索条件，或者新增一名学生。</p>
    </div>

    <div v-else class="student-grid">
      <article v-for="student in students" :key="student.id" class="student-card">
        <div class="student-card-head">
          <div class="avatar">{{ student.name.slice(0, 1) }}</div>
          <div>
            <h2>{{ student.name }}</h2>
            <p>{{ student.age }} 岁 · {{ student.address.city }}</p>
          </div>
          <span class="score-badge">{{ averageScore(student.courses) }} 分</span>
        </div>

        <dl class="student-meta">
          <div>
            <dt>电话</dt>
            <dd>{{ student.phone || "未填写" }}</dd>
          </div>
          <div>
            <dt>地址</dt>
            <dd>{{ student.address.city }} · {{ student.address.street }}</dd>
          </div>
          <div>
            <dt>更新时间</dt>
            <dd>{{ formatDateTime(student.updatedAt) }}</dd>
          </div>
        </dl>

        <div class="course-tags">
          <span v-for="course in student.courses" :key="course.name">
            {{ course.name }} {{ course.score }}
          </span>
          <span v-if="student.courses.length === 0">暂无课程</span>
        </div>

        <RouterLink class="detail-link" :to="`/students/${student.id}`">
          查看完整对象 <span>→</span>
        </RouterLink>
      </article>
    </div>
  </section>
</template>
