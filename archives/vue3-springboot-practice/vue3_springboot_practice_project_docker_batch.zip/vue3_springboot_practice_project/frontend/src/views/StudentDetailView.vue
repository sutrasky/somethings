<script setup>
import { ref, watch } from "vue";
import { useRouter } from "vue-router";

import { deleteStudent, getStudent } from "../api/client";
import { averageScore, formatDateTime } from "../utils/format";

const props = defineProps({
  id: {
    type: String,
    required: true
  }
});

const router = useRouter();
const student = ref(null);
const loading = ref(true);
const errorMessage = ref("");
const deleting = ref(false);

async function load() {
  loading.value = true;
  errorMessage.value = "";
  try {
    student.value = await getStudent(props.id);
  } catch (error) {
    errorMessage.value = error.message;
  } finally {
    loading.value = false;
  }
}

async function remove() {
  if (!window.confirm(`确认删除学生“${student.value.name}”吗？`)) {
    return;
  }
  deleting.value = true;
  try {
    await deleteStudent(props.id);
    router.push("/");
  } catch (error) {
    errorMessage.value = error.message;
  } finally {
    deleting.value = false;
  }
}

watch(() => props.id, load, { immediate: true });
</script>

<template>
  <section>
    <div class="page-heading">
      <button class="ghost-button" type="button" @click="router.back()">
        ← 返回
      </button>
      <div v-if="student" class="heading-actions">
        <RouterLink class="secondary-button" :to="`/students/${id}/edit`">
          编辑
        </RouterLink>
        <button class="danger-button" type="button" :disabled="deleting" @click="remove">
          {{ deleting ? "删除中……" : "删除学生" }}
        </button>
      </div>
    </div>

    <div v-if="loading" class="loading-card">正在加载学生完整对象……</div>
    <div v-else-if="errorMessage" class="alert alert-error">{{ errorMessage }}</div>

    <template v-else-if="student">
      <header class="profile-hero">
        <div class="profile-avatar">{{ student.name.slice(0, 1) }}</div>
        <div>
          <p class="eyebrow">STUDENT DETAIL · ID {{ student.id }}</p>
          <h1>{{ student.name }}</h1>
          <p>{{ student.age }} 岁 · {{ student.address.city }}</p>
        </div>
        <div class="profile-score">
          <strong>{{ averageScore(student.courses) }}</strong>
          <span>平均成绩</span>
        </div>
      </header>

      <div class="detail-grid">
        <article class="detail-card">
          <p class="card-label">BASIC INFO</p>
          <h2>基本信息</h2>
          <dl class="detail-list">
            <div><dt>学生 ID</dt><dd>{{ student.id }}</dd></div>
            <div><dt>姓名</dt><dd>{{ student.name }}</dd></div>
            <div><dt>年龄</dt><dd>{{ student.age }}</dd></div>
            <div><dt>电话</dt><dd>{{ student.phone || "未填写" }}</dd></div>
            <div><dt>创建时间</dt><dd>{{ formatDateTime(student.createdAt) }}</dd></div>
            <div><dt>更新时间</dt><dd>{{ formatDateTime(student.updatedAt) }}</dd></div>
          </dl>
        </article>

        <article class="detail-card address-card">
          <p class="card-label">NESTED OBJECT</p>
          <h2>地址</h2>
          <div class="address-visual">
            <span class="pin">⌖</span>
            <div>
              <strong>{{ student.address.city }}</strong>
              <p>{{ student.address.street }}</p>
            </div>
          </div>
          <pre>{{ JSON.stringify(student.address, null, 2) }}</pre>
        </article>
      </div>

      <article class="detail-card course-detail-card">
        <div class="section-title-row">
          <div>
            <p class="card-label">COMPLEX ARRAY</p>
            <h2>课程与成绩</h2>
          </div>
          <span class="counter">{{ student.courses.length }} 门</span>
        </div>
        <div v-if="student.courses.length === 0" class="empty-inline">
          该学生还没有课程。
        </div>
        <div v-else class="course-score-grid">
          <article v-for="course in student.courses" :key="course.name">
            <span>{{ course.name }}</span>
            <strong>{{ course.score }}</strong>
            <div class="score-track">
              <i :style="{ width: `${course.score}%` }"></i>
            </div>
          </article>
        </div>
      </article>

      <article class="detail-card raw-json-card">
        <p class="card-label">FULL JSON</p>
        <h2>完整前后端数据结构</h2>
        <pre>{{ JSON.stringify(student, null, 2) }}</pre>
      </article>
    </template>
  </section>
</template>
