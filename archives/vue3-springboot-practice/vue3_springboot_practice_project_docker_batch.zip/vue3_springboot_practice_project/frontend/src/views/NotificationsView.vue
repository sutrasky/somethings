<script setup>
import { computed, onMounted, reactive, ref } from "vue";

import { useNotifications } from "../composables/useNotifications";
import { formatDateTime } from "../utils/format";

const {
  connected,
  connectionText,
  messages,
  lastError,
  connect,
  sendClientNotification,
  sendSystemBroadcast
} = useNotifications();

const form = reactive({
  title: "前端消息",
  sender: "Vue 用户",
  content: ""
});
const localError = ref("");
const sending = ref(false);

const scheduledCount = computed(
  () => messages.value.filter((message) => message.kind === "SCHEDULE").length
);

function sendStomp() {
  localError.value = "";
  if (!form.content.trim()) {
    localError.value = "消息内容不能为空。";
    return;
  }
  const sent = sendClientNotification({
    title: form.title,
    sender: form.sender,
    content: form.content
  });
  if (!sent) {
    localError.value = "WebSocket 尚未连接。";
    return;
  }
  form.content = "";
}

async function sendRestSystem() {
  localError.value = "";
  if (!form.content.trim()) {
    localError.value = "消息内容不能为空。";
    return;
  }
  sending.value = true;
  try {
    await sendSystemBroadcast({
      title: form.title,
      sender: form.sender,
      content: form.content
    });
    form.content = "";
  } catch (error) {
    localError.value = error.message;
  } finally {
    sending.value = false;
  }
}

onMounted(connect);
</script>

<template>
  <section>
    <div class="hero-panel messaging-hero">
      <div>
        <p class="eyebrow">SPRING MESSAGING · STOMP · WEBSOCKET</p>
        <h1>实时消息中心</h1>
        <p>
          浏览器通过 STOMP 向 <code>/app/notifications/send</code> 发送消息，
          Spring Boot 通过 <code>@MessageMapping</code> 接收，
          再用 <code>@SendTo</code> 广播到订阅者。
        </p>
      </div>
      <div class="live-stat">
        <span class="status-dot" :class="{ online: connected }"></span>
        <strong>{{ messages.length }}</strong>
        <small>当前消息</small>
      </div>
    </div>

    <div class="connection-banner" :class="{ online: connected }">
      <span class="status-dot" :class="{ online: connected }"></span>
      <p>{{ connectionText }}</p>
      <span>定时消息 {{ scheduledCount }} 条</span>
    </div>

    <div class="messaging-layout">
      <form class="form-card compact-form" @submit.prevent="sendStomp">
        <p class="card-label">SEND MESSAGE</p>
        <h2>发送通知</h2>
        <label class="field">
          <span>标题</span>
          <input v-model.trim="form.title" maxlength="80" />
        </label>
        <label class="field">
          <span>发送者</span>
          <input v-model.trim="form.sender" maxlength="50" />
        </label>
        <label class="field">
          <span>消息内容</span>
          <textarea
            v-model.trim="form.content"
            rows="5"
            maxlength="500"
            placeholder="发送给所有订阅 /topic/notifications 的客户端"
          ></textarea>
        </label>
        <div class="button-row">
          <button class="primary-button" type="submit" :disabled="!connected">
            STOMP 发送
          </button>
          <button
            class="secondary-button"
            type="button"
            :disabled="sending"
            @click="sendRestSystem"
          >
            REST → /topic/system
          </button>
        </div>
        <p v-if="localError || lastError" class="field-error">
          {{ localError || lastError }}
        </p>

        <div class="message-flow">
          <span>Vue</span><i>→</i><span>/app</span><i>→</i><span>@MessageMapping</span>
          <i>→</i><span>/topic</span>
        </div>
      </form>

      <article class="notification-panel">
        <div class="section-title-row">
          <div>
            <p class="card-label">LIVE FEED</p>
            <h2>实时消息流</h2>
          </div>
          <span class="counter">{{ messages.length }} 条</span>
        </div>

        <div v-if="messages.length === 0" class="empty-card">
          等待消息。每 10 秒会收到一条 @Scheduled 推送。
        </div>
        <div v-else class="notification-list">
          <article
            v-for="message in messages"
            :key="message.id"
            class="notification-item"
            :class="`kind-${message.kind.toLowerCase()}`"
          >
            <div class="notification-head">
              <span class="kind-chip">{{ message.kind }}</span>
              <time>{{ formatDateTime(message.createdAt) }}</time>
            </div>
            <h3>{{ message.title }}</h3>
            <p>{{ message.content }}</p>
            <footer>
              <span>{{ message.sender }}</span>
              <code>{{ message.source }}</code>
            </footer>
          </article>
        </div>
      </article>
    </div>
  </section>
</template>
