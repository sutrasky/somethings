<script setup>
import { computed, onMounted, ref } from "vue";

import {
  ApiError,
  getBatchExecutions,
  getBatchJobs,
  getDashboard,
  launchStudentImport
} from "../api/client";
import { formatDateTime } from "../utils/format";

const jobs = ref([]);
const executions = ref([]);
const dashboard = ref(null);
const loading = ref(true);
const running = ref(false);
const errorMessage = ref("");
const successMessage = ref("");

const latest = computed(() => executions.value[0] ?? null);

async function load() {
  loading.value = true;
  errorMessage.value = "";
  try {
    const [jobList, executionList, dashboardData] = await Promise.all([
      getBatchJobs(),
      getBatchExecutions(),
      getDashboard()
    ]);
    jobs.value = jobList;
    executions.value = executionList;
    dashboard.value = dashboardData;
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError ? error.message : `加载失败：${error.message}`;
  } finally {
    loading.value = false;
  }
}

async function runBatch() {
  running.value = true;
  errorMessage.value = "";
  successMessage.value = "";
  try {
    const result = await launchStudentImport();
    successMessage.value =
      `Job ${result.status}：读取 ${result.readCount} 条，写入 ${result.writeCount} 条。`;
    await load();
  } catch (error) {
    errorMessage.value =
      error instanceof ApiError ? error.message : `执行失败：${error.message}`;
  } finally {
    running.value = false;
  }
}

onMounted(load);
</script>

<template>
  <section>
    <div class="hero-panel batch-hero">
      <div>
        <p class="eyebrow">SPRING BATCH 6 · REST API · MYSQL</p>
        <h1>CSV 学生批量导入</h1>
        <p>
          一个可重复触发的 Chunk Job：读取 CSV、校验转换、写入 MySQL，
          并由 JobRepository 持久化 Job 和 Step 执行历史。
        </p>
      </div>
      <button class="primary-button" type="button" :disabled="running" @click="runBatch">
        {{ running ? "Batch 执行中……" : "启动导入 Job" }}
        <span>▶</span>
      </button>
    </div>

    <div class="batch-flow">
      <article><span>01</span><strong>CSV Reader</strong><small>FlatFileItemReader</small></article>
      <i>→</i>
      <article><span>02</span><strong>Validator</strong><small>ItemProcessor</small></article>
      <i>→</i>
      <article><span>03</span><strong>Chunk Writer</strong><small>ItemWriter</small></article>
      <i>→</i>
      <article><span>04</span><strong>MySQL</strong><small>students + BATCH_*</small></article>
    </div>

    <div class="stats-grid batch-stats">
      <article>
        <span>数据库学生</span>
        <strong>{{ dashboard?.totalStudents ?? 0 }}</strong>
        <small>当前 MySQL 记录</small>
      </article>
      <article>
        <span>课程记录</span>
        <strong>{{ dashboard?.totalCourses ?? 0 }}</strong>
        <small>student_courses</small>
      </article>
      <article>
        <span>最近 Job</span>
        <strong class="text-stat">{{ latest?.status ?? "NOT RUN" }}</strong>
        <small>{{ latest ? `Execution #${latest.executionId}` : "等待触发" }}</small>
      </article>
    </div>

    <div v-if="errorMessage" class="alert alert-error">{{ errorMessage }}</div>
    <div v-if="successMessage" class="batch-success">{{ successMessage }}</div>

    <div class="batch-layout">
      <article class="detail-card">
        <p class="card-label">JOB DEFINITION</p>
        <h2>Batch Job 信息</h2>
        <div v-if="loading" class="empty-inline">正在加载 Job 元数据……</div>
        <div v-else class="job-definition-list">
          <div v-for="job in jobs" :key="job.jobName">
            <span>JOB</span><strong>{{ job.jobName }}</strong>
            <span>STEP</span><strong>{{ job.stepName }}</strong>
            <span>INPUT</span><code>{{ job.input }}</code>
          </div>
        </div>
        <p class="batch-note">
          同名且同电话的学生会被跳过，因此重复启动 Job 不会重复插入 CSV 中的同一批学生。
        </p>
      </article>

      <article class="detail-card">
        <p class="card-label">LATEST EXECUTION</p>
        <h2>最近一次执行</h2>
        <div v-if="!latest" class="empty-inline">还没有执行记录。</div>
        <dl v-else class="detail-list">
          <div><dt>状态</dt><dd>{{ latest.status }}</dd></div>
          <div><dt>读取</dt><dd>{{ latest.readCount }} 条</dd></div>
          <div><dt>写入</dt><dd>{{ latest.writeCount }} 条</dd></div>
          <div><dt>提交</dt><dd>{{ latest.commitCount }} 次</dd></div>
          <div><dt>开始</dt><dd>{{ formatDateTime(latest.startTime) }}</dd></div>
          <div><dt>结束</dt><dd>{{ formatDateTime(latest.endTime) }}</dd></div>
        </dl>
      </article>
    </div>

    <article class="detail-card batch-history">
      <div class="section-title-row">
        <div>
          <p class="card-label">JOB REPOSITORY</p>
          <h2>Batch 执行历史</h2>
        </div>
        <button class="ghost-button" type="button" @click="load">刷新</button>
      </div>

      <div v-if="executions.length === 0" class="empty-inline">
        点击“启动导入 Job”生成第一条执行记录。
      </div>
      <div v-else class="batch-table-wrap">
        <table class="batch-table">
          <thead>
            <tr>
              <th>Execution</th>
              <th>Status</th>
              <th>Exit</th>
              <th>Read</th>
              <th>Write</th>
              <th>Commit</th>
              <th>Started</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="execution in executions" :key="execution.executionId">
              <td>#{{ execution.executionId }}</td>
              <td><span class="batch-status">{{ execution.status }}</span></td>
              <td>{{ execution.exitCode }}</td>
              <td>{{ execution.readCount }}</td>
              <td>{{ execution.writeCount }}</td>
              <td>{{ execution.commitCount }}</td>
              <td>{{ formatDateTime(execution.startTime) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </article>

    <article class="detail-card api-card">
      <p class="card-label">REST API</p>
      <h2>REST 管理接口</h2>
      <div class="api-grid">
        <div><code>GET /api/dashboard</code><span>学生、课程、最近 Batch 汇总</span></div>
        <div><code>GET /api/batch/jobs</code><span>Job 元数据</span></div>
        <div><code>POST /api/batch/student-import</code><span>启动 CSV 导入</span></div>
        <div><code>GET /api/batch/executions</code><span>查询执行历史</span></div>
        <div><code>GET /api/batch/executions/{id}</code><span>查询单次执行</span></div>
      </div>
    </article>
  </section>
</template>
