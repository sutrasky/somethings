<script setup>
import { computed, onMounted, reactive, ref } from "vue";
import { useRoute, useRouter } from "vue-router";

import {
  ApiError,
  createStudent,
  getStudent,
  updateStudent
} from "../api/client";

const route = useRoute();
const router = useRouter();
const isEdit = computed(() => route.name === "student-edit");

const form = reactive({
  name: "",
  age: 18,
  phone: "",
  address: {
    city: "",
    street: ""
  },
  courses: []
});

const errors = reactive({});
const loading = ref(false);
const submitting = ref(false);
const requestError = ref("");

function clearErrors() {
  Object.keys(errors).forEach((key) => delete errors[key]);
}

function setForm(data) {
  form.name = data.name ?? "";
  form.age = data.age ?? 18;
  form.phone = data.phone ?? "";
  form.address.city = data.address?.city ?? "";
  form.address.street = data.address?.street ?? "";
  form.courses = (data.courses ?? []).map((course) => ({ ...course }));
}

function addCourse() {
  form.courses.push({ name: "", score: 80 });
}

function removeCourse(index) {
  form.courses.splice(index, 1);
}

function errorText(key) {
  return errors[key] || "";
}

async function loadForEdit() {
  if (!isEdit.value) {
    return;
  }
  loading.value = true;
  try {
    setForm(await getStudent(route.params.id));
  } catch (error) {
    requestError.value = error.message;
  } finally {
    loading.value = false;
  }
}

async function submit() {
  clearErrors();
  requestError.value = "";
  submitting.value = true;
  try {
    const saved = isEdit.value
      ? await updateStudent(route.params.id, form)
      : await createStudent(form);
    router.push(`/students/${saved.id}`);
  } catch (error) {
    if (error instanceof ApiError) {
      Object.assign(errors, error.fieldErrors);
      requestError.value = error.message;
    } else {
      requestError.value = `保存失败：${error.message}`;
    }
  } finally {
    submitting.value = false;
  }
}

onMounted(loadForEdit);
</script>

<template>
  <section>
    <div class="page-heading">
      <div>
        <p class="eyebrow">{{ isEdit ? "UPDATE" : "CREATE" }}</p>
        <h1>{{ isEdit ? "编辑学生" : "新增学生" }}</h1>
        <p>练习把嵌套地址和课程列表作为完整 JSON 对象提交给 Spring Boot。</p>
      </div>
      <button class="ghost-button" type="button" @click="router.back()">
        返回
      </button>
    </div>

    <div v-if="loading" class="loading-card">正在加载学生详情……</div>

    <form v-else class="form-card" @submit.prevent="submit">
      <section class="form-section">
        <h2>基本信息</h2>
        <div class="form-grid">
          <label class="field">
            <span>姓名 <em>必填</em></span>
            <input
              v-model.trim="form.name"
              :class="{ invalid: errors.name }"
              maxlength="50"
            />
            <small v-if="errors.name" class="field-error">{{ errors.name }}</small>
          </label>

          <label class="field">
            <span>年龄 <em>1–120</em></span>
            <input
              v-model.number="form.age"
              type="number"
              min="1"
              max="120"
              :class="{ invalid: errors.age }"
            />
            <small v-if="errors.age" class="field-error">{{ errors.age }}</small>
          </label>

          <label class="field">
            <span>电话</span>
            <input
              v-model.trim="form.phone"
              :class="{ invalid: errors.phone }"
              placeholder="数字、空格、+ 或 -"
            />
            <small v-if="errors.phone" class="field-error">{{ errors.phone }}</small>
          </label>
        </div>
      </section>

      <section class="form-section">
        <h2>嵌套地址对象</h2>
        <div class="form-grid">
          <label class="field">
            <span>城市 <em>必填</em></span>
            <input
              v-model.trim="form.address.city"
              :class="{ invalid: errorText('address.city') }"
            />
            <small v-if="errorText('address.city')" class="field-error">
              {{ errorText("address.city") }}
            </small>
          </label>

          <label class="field wide">
            <span>街道 <em>必填</em></span>
            <input
              v-model.trim="form.address.street"
              :class="{ invalid: errorText('address.street') }"
            />
            <small v-if="errorText('address.street')" class="field-error">
              {{ errorText("address.street") }}
            </small>
          </label>
        </div>
      </section>

      <section class="form-section">
        <div class="section-title-row">
          <div>
            <h2>课程列表</h2>
            <p>这是复杂对象中的数组，可以添加任意多门课程。</p>
          </div>
          <button class="secondary-button" type="button" @click="addCourse">
            添加课程
          </button>
        </div>

        <div v-if="form.courses.length === 0" class="empty-inline">
          还没有课程，点击“添加课程”。
        </div>

        <div v-else class="course-editor-list">
          <div
            v-for="(course, index) in form.courses"
            :key="index"
            class="course-editor-row"
          >
            <label class="field">
              <span>课程名称</span>
              <input
                v-model.trim="course.name"
                :class="{ invalid: errorText(`courses[${index}].name`) }"
              />
              <small
                v-if="errorText(`courses[${index}].name`)"
                class="field-error"
              >
                {{ errorText(`courses[${index}].name`) }}
              </small>
            </label>
            <label class="field score-field">
              <span>成绩</span>
              <input
                v-model.number="course.score"
                type="number"
                min="0"
                max="100"
                :class="{ invalid: errorText(`courses[${index}].score`) }"
              />
              <small
                v-if="errorText(`courses[${index}].score`)"
                class="field-error"
              >
                {{ errorText(`courses[${index}].score`) }}
              </small>
            </label>
            <button
              class="danger-ghost"
              type="button"
              @click="removeCourse(index)"
            >
              删除
            </button>
          </div>
        </div>
      </section>

      <div v-if="requestError" class="alert alert-error">{{ requestError }}</div>

      <div class="form-actions">
        <button class="primary-button" type="submit" :disabled="submitting">
          {{ submitting ? "正在保存……" : "提交复杂对象" }}
        </button>
        <button class="ghost-button" type="button" @click="router.back()">
          取消
        </button>
      </div>
    </form>
  </section>
</template>
