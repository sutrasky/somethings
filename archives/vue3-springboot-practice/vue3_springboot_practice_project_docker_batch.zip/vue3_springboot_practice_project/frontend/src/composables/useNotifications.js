import { Client } from "@stomp/stompjs";
import { computed, ref } from "vue";

import {
  ApiError,
  broadcastSystemNotification,
  getRecentNotifications
} from "../api/client";

const connected = ref(false);
const connectionText = ref("尚未连接");
const messages = ref([]);
const lastError = ref("");

let client = null;

function addMessages(incoming) {
  const list = Array.isArray(incoming) ? incoming : [incoming];
  const byId = new Map(messages.value.map((message) => [message.id, message]));
  for (const message of list) {
    byId.set(message.id, message);
  }
  messages.value = [...byId.values()]
    .sort((left, right) => new Date(right.createdAt) - new Date(left.createdAt))
    .slice(0, 50);
}

function websocketUrl() {
  const scheme = window.location.protocol === "https:" ? "wss" : "ws";
  return `${scheme}://${window.location.host}/ws`;
}

async function loadInitialHistory() {
  try {
    addMessages(await getRecentNotifications());
  } catch {
    // The STOMP @SubscribeMapping response remains the primary source.
  }
}

function connect() {
  if (client?.active) {
    return;
  }

  lastError.value = "";
  loadInitialHistory();

  client = new Client({
    brokerURL: websocketUrl(),
    reconnectDelay: 3000,
    debug: () => {},
    onConnect: () => {
      connected.value = true;
      connectionText.value = `已连接 ${websocketUrl()}`;

      client.subscribe("/topic/notifications", (frame) => {
        addMessages(JSON.parse(frame.body));
      });

      client.subscribe("/topic/system", (frame) => {
        addMessages(JSON.parse(frame.body));
      });

      client.subscribe("/app/notifications/init", (frame) => {
        addMessages(JSON.parse(frame.body));
      });
    },
    onWebSocketClose: () => {
      connected.value = false;
      connectionText.value = "连接已断开，3 秒后自动重连";
    },
    onStompError: (frame) => {
      lastError.value = frame.headers.message || "STOMP 处理失败";
    },
    onWebSocketError: () => {
      connected.value = false;
      connectionText.value = "WebSocket 连接失败";
    }
  });

  client.activate();
}

function disconnect() {
  if (client) {
    client.deactivate();
    connected.value = false;
  }
}

function sendClientNotification(payload) {
  if (!connected.value || !client) {
    return false;
  }
  client.publish({
    destination: "/app/notifications/send",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });
  return true;
}

async function sendSystemBroadcast(payload) {
  try {
    lastError.value = "";
    return await broadcastSystemNotification(payload);
  } catch (error) {
    lastError.value =
      error instanceof ApiError ? error.message : error.message;
    throw error;
  }
}

export function useNotifications() {
  return {
    connected,
    connectionText,
    messages,
    lastError,
    unreadCount: computed(() => messages.value.length),
    connect,
    disconnect,
    sendClientNotification,
    sendSystemBroadcast
  };
}
