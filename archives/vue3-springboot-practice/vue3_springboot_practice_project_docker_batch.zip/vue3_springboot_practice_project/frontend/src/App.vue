<script setup>
import { onBeforeUnmount, onMounted } from "vue";
import { RouterLink, RouterView } from "vue-router";

import { useNotifications } from "./composables/useNotifications";

const { connected, messages, connect, disconnect } = useNotifications();

onMounted(connect);
onBeforeUnmount(disconnect);
</script>

<template>
  <div class="app-shell">
    <header class="topbar">
      <RouterLink to="/" class="brand">
        <span class="brand-mark">S</span>
        <span>
          <strong>Student Practice Lab</strong>
          <small>Spring Boot · MySQL · Vue 3</small>
        </span>
      </RouterLink>

      <nav class="main-nav">
        <RouterLink to="/" exact-active-class="active">学生管理</RouterLink>
        <RouterLink to="/students/new" active-class="active">新增学生</RouterLink>
        <RouterLink to="/notifications" active-class="active">
          消息中心
          <span v-if="messages.length" class="nav-badge">{{ messages.length }}</span>
        </RouterLink>
        <RouterLink to="/batch" active-class="active">Batch</RouterLink>
        <RouterLink to="/exercises" active-class="active">练习题</RouterLink>
      </nav>

      <div class="connection-pill" :class="{ online: connected }">
        <span class="status-dot"></span>
        {{ connected ? "STOMP ONLINE" : "RECONNECTING" }}
      </div>
    </header>

    <main class="page-container">
      <RouterView v-slot="{ Component }">
        <Transition name="page" mode="out-in">
          <component :is="Component" />
        </Transition>
      </RouterView>
    </main>

    <footer class="app-footer">
      <span>Vue Router 学生管理系统 · Spring Boot 4.1.2</span>
      <span>MySQL 8.4 · REST API · Batch · Messaging · Scheduling</span>
    </footer>
  </div>
</template>
