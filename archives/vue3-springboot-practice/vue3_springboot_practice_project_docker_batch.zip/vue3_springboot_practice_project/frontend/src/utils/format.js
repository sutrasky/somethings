const dateTimeFormatter = new Intl.DateTimeFormat("zh-CN", {
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hour12: false
});

export function formatDateTime(value) {
  return value ? dateTimeFormatter.format(new Date(value)) : "—";
}

export function averageScore(courses = []) {
  if (!courses.length) {
    return 0;
  }
  return Math.round(
    courses.reduce((sum, course) => sum + course.score, 0) / courses.length
  );
}
