import { createRouter, createWebHistory } from "vue-router";

import ExercisesView from "../views/ExercisesView.vue";
import BatchView from "../views/BatchView.vue";
import NotificationsView from "../views/NotificationsView.vue";
import StudentDetailView from "../views/StudentDetailView.vue";
import StudentFormView from "../views/StudentFormView.vue";
import StudentsView from "../views/StudentsView.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      name: "students",
      component: StudentsView
    },
    {
      path: "/students/new",
      name: "student-create",
      component: StudentFormView
    },
    {
      path: "/students/:id",
      name: "student-detail",
      component: StudentDetailView,
      props: true
    },
    {
      path: "/students/:id/edit",
      name: "student-edit",
      component: StudentFormView,
      props: true
    },
    {
      path: "/notifications",
      name: "notifications",
      component: NotificationsView
    },
    {
      path: "/exercises",
      name: "exercises",
      component: ExercisesView
    },
    {
      path: "/batch",
      name: "batch",
      component: BatchView
    }
  ],
  scrollBehavior() {
    return { top: 0, behavior: "smooth" };
  }
});

export default router;
