export class ApiError extends Error {
  constructor(message, status, fieldErrors = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function request(url, options = {}) {
  const response = await fetch(url, options);

  if (!response.ok) {
    let payload = null;
    try {
      payload = await response.json();
    } catch {
      // Some proxy or infrastructure errors do not have a JSON body.
    }
    throw new ApiError(
      payload?.message ?? `请求失败：HTTP ${response.status}`,
      response.status,
      payload?.errors ?? {}
    );
  }

  if (response.status === 204) {
    return null;
  }
  return response.json();
}

function jsonOptions(method, payload) {
  return {
    method,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json"
    },
    body: JSON.stringify(payload)
  };
}

export function getStudents(query = "") {
  const suffix = query.trim()
    ? `?query=${encodeURIComponent(query.trim())}`
    : "";
  return request(`/api/students${suffix}`);
}

export function getStudent(id) {
  return request(`/api/students/${id}`);
}

export function createStudent(student) {
  return request("/api/students", jsonOptions("POST", student));
}

export function updateStudent(id, student) {
  return request(`/api/students/${id}`, jsonOptions("PUT", student));
}

export function deleteStudent(id) {
  return request(`/api/students/${id}`, { method: "DELETE" });
}

export function getDashboard() {
  return request("/api/dashboard", { cache: "no-store" });
}

export function getBatchJobs() {
  return request("/api/batch/jobs");
}

export function launchStudentImport() {
  return request("/api/batch/student-import", { method: "POST" });
}

export function getBatchExecutions(limit = 10) {
  return request(`/api/batch/executions?limit=${limit}`, {
    cache: "no-store"
  });
}

export function getBatchExecution(id) {
  return request(`/api/batch/executions/${id}`, { cache: "no-store" });
}

export function getRecentNotifications() {
  return request("/api/notifications/recent", { cache: "no-store" });
}

export function broadcastSystemNotification(notification) {
  return request(
    "/api/notifications/system",
    jsonOptions("POST", notification)
  );
}
