import { Client } from "@stomp/stompjs";

const brokerUrl = process.env.WS_URL || "ws://localhost:8080/ws";
const expected = `Vue STOMP smoke ${Date.now()}`;
const client = new Client({
  brokerURL: brokerUrl,
  reconnectDelay: 0,
  debug: () => {}
});

const timeout = setTimeout(
  () => fail("WebSocket STOMP smoke test timed out"),
  8000
);

client.onConnect = () => {
  client.subscribe("/topic/notifications", (frame) => {
    const message = JSON.parse(frame.body);
    if (message.content === expected) {
      clearTimeout(timeout);
      console.log(`STOMP OK: ${message.title} / ${message.content}`);
      client.deactivate().finally(() => process.exit(0));
    }
  });

  client.publish({
    destination: "/app/notifications/send",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      title: "Smoke Test",
      sender: "Node",
      content: expected
    })
  });
};

client.onStompError = (frame) => {
  fail(frame.headers.message || "STOMP error");
};

client.onWebSocketError = () => fail("WebSocket connection failed");
client.activate();

function fail(message) {
  console.error(message);
  client.deactivate().finally(() => process.exit(1));
}
