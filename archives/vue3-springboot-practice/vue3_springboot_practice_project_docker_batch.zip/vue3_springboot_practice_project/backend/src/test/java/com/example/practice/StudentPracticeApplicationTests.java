package com.example.practice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.transaction.annotation.Transactional;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class StudentPracticeApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void seededStudentsAreAvailable() throws Exception {
        mockMvc.perform(get("/api/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].address.city").exists())
                .andExpect(jsonPath("$[0].courses").isArray());
    }

    @Test
    void complexStudentCanBeCreatedAndRead() throws Exception {
        String json = """
                {
                  "name": "王五",
                  "age": 22,
                  "phone": "13800000003",
                  "address": {
                    "city": "南京",
                    "street": "鼓楼区中山路 300 号"
                  },
                  "courses": [
                    {"name": "Spring Messaging", "score": 96},
                    {"name": "MySQL", "score": 89}
                  ]
                }
                """;

        MvcResult created = mockMvc.perform(post("/api/students")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("王五"))
                .andExpect(jsonPath("$.address.city").value("南京"))
                .andExpect(jsonPath("$.courses[0].name").value("Spring Messaging"))
                .andReturn();

        JsonNode body = objectMapper.readTree(created.getResponse().getContentAsString());
        mockMvc.perform(get("/api/students/{id}", body.get("id").asLong()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.courses.length()").value(2))
                .andExpect(jsonPath("$.createdAt").exists());
    }

    @Test
    void studentCanBeUpdatedAndDeleted() throws Exception {
        MvcResult list = mockMvc.perform(get("/api/students"))
                .andExpect(status().isOk())
                .andReturn();
        long id = objectMapper.readTree(list.getResponse().getContentAsString())
                .get(0).get("id").asLong();

        mockMvc.perform(put("/api/students/{id}", id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "更新后的学生",
                                  "age": 23,
                                  "phone": null,
                                  "address": {"city": "苏州", "street": "工业园区"},
                                  "courses": [{"name": "Vue Router", "score": 95}]
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("更新后的学生"))
                .andExpect(jsonPath("$.courses[0].score").value(95));

        mockMvc.perform(delete("/api/students/{id}", id))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/students/{id}", id))
                .andExpect(status().isNotFound());
    }

    @Test
    void nestedValidationReturnsFieldErrors() throws Exception {
        mockMvc.perform(post("/api/students")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "",
                                  "age": 0,
                                  "phone": "bad-phone",
                                  "address": {"city": "", "street": ""},
                                  "courses": [{"name": "", "score": 101}]
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.name").exists())
                .andExpect(jsonPath("$.errors.age").exists())
                .andExpect(jsonPath("$.errors['address.city']").exists())
                .andExpect(jsonPath("$.errors['courses[0].score']").exists());
    }

    @Test
    void notificationsCanBeBroadcastAndListed() throws Exception {
        mockMvc.perform(post("/api/notifications/system")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "title": "测试广播",
                                  "content": "SimpMessagingTemplate test",
                                  "sender": "JUnit"
                                }
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.source").value("REST_SIMP_MESSAGING_TEMPLATE"));

        mockMvc.perform(get("/api/notifications/recent"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].content").value("SimpMessagingTemplate test"));
    }

    @Test
    void vueRouterHistoryRouteFallsBackToIndexHtml() throws Exception {
        mockMvc.perform(get("/students/1"))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));

        mockMvc.perform(get("/batch"))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl("/index.html"));
    }
}
