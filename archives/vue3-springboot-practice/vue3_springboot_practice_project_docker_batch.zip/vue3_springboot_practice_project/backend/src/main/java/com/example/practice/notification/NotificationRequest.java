package com.example.practice.notification;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record NotificationRequest(
        @Size(max = 80, message = "标题不能超过 80 个字符")
        String title,

        @NotBlank(message = "消息内容不能为空")
        @Size(max = 500, message = "消息内容不能超过 500 个字符")
        String content,

        @Size(max = 50, message = "发送者名称不能超过 50 个字符")
        String sender) {
}
