package com.example.practice.common;

import java.time.LocalDateTime;
import java.util.Map;

public record ApiError(
        String message,
        Map<String, String> errors,
        LocalDateTime timestamp) {

    public static ApiError of(String message) {
        return new ApiError(message, Map.of(), LocalDateTime.now());
    }
}
