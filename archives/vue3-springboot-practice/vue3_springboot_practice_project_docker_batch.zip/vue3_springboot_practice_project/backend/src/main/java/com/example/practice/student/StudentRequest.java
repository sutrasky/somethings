package com.example.practice.student;

import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record StudentRequest(
        @NotBlank(message = "姓名不能为空")
        @Size(max = 50, message = "姓名不能超过 50 个字符")
        String name,

        @NotNull(message = "年龄不能为空")
        @Min(value = 1, message = "年龄不能小于 1")
        @Max(value = 120, message = "年龄不能大于 120")
        Integer age,

        @Pattern(
                regexp = "^$|^[0-9+\\- ]{6,30}$",
                message = "电话只能包含数字、空格、加号或短横线，长度 6-30")
        String phone,

        @Valid
        @NotNull(message = "地址不能为空")
        Address address,

        List<@Valid Course> courses) {

    public record Address(
            @NotBlank(message = "城市不能为空")
            @Size(max = 80, message = "城市不能超过 80 个字符")
            String city,

            @NotBlank(message = "街道不能为空")
            @Size(max = 160, message = "街道不能超过 160 个字符")
            String street) {
    }

    public record Course(
            @NotBlank(message = "课程名称不能为空")
            @Size(max = 80, message = "课程名称不能超过 80 个字符")
            String name,

            @NotNull(message = "课程成绩不能为空")
            @Min(value = 0, message = "成绩不能小于 0")
            @Max(value = 100, message = "成绩不能大于 100")
            Integer score) {
    }
}
