package com.example.practice.batch;

public record StudentCsvRow(
        String name,
        Integer age,
        String phone,
        String city,
        String street,
        String course1,
        Integer course1Score,
        String course2,
        Integer course2Score) {
}
