package com.example.practice.config;

import java.util.List;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.example.practice.student.StudentRequest;
import com.example.practice.student.StudentService;

@Component
@ConditionalOnProperty(
        name = "practice.seed.enabled",
        havingValue = "true",
        matchIfMissing = true)
public class DataInitializer implements ApplicationRunner {

    private final StudentService studentService;

    public DataInitializer(StudentService studentService) {
        this.studentService = studentService;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (studentService.count() > 0) {
            return;
        }

        studentService.create(new StudentRequest(
                "张三",
                20,
                "13800000001",
                new StudentRequest.Address("上海", "浦东新区世纪大道 100 号"),
                List.of(
                        new StudentRequest.Course("Spring Boot", 92),
                        new StudentRequest.Course("Vue 3", 88))));

        studentService.create(new StudentRequest(
                "李四",
                21,
                "13800000002",
                new StudentRequest.Address("杭州", "西湖区文一路 200 号"),
                List.of(
                        new StudentRequest.Course("MySQL", 85),
                        new StudentRequest.Course("WebSocket", 90))));
    }
}
