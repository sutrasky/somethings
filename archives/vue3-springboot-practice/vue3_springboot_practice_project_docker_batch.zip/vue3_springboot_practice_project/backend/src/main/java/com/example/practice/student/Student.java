package com.example.practice.student;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(nullable = false)
    private Integer age;

    @Column(length = 30)
    private String phone;

    @Column(nullable = false, length = 80)
    private String city;

    @Column(nullable = false, length = 160)
    private String street;

    @ElementCollection
    @CollectionTable(
            name = "student_courses",
            joinColumns = @JoinColumn(name = "student_id"))
    private List<Course> courses = new ArrayList<>();

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    protected Student() {
    }

    public Student(
            String name,
            Integer age,
            String phone,
            String city,
            String street,
            List<Course> courses) {
        replace(name, age, phone, city, street, courses);
    }

    public void replace(
            String name,
            Integer age,
            String phone,
            String city,
            String street,
            List<Course> courses) {
        this.name = name.strip();
        this.age = age;
        this.phone = phone == null || phone.isBlank() ? null : phone.strip();
        this.city = city.strip();
        this.street = street.strip();
        this.courses.clear();
        if (courses != null) {
            this.courses.addAll(courses);
        }
    }

    @PrePersist
    void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Integer getAge() {
        return age;
    }

    public String getPhone() {
        return phone;
    }

    public String getCity() {
        return city;
    }

    public String getStreet() {
        return street;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    @Embeddable
    public static class Course {

        @Column(name = "course_name", nullable = false, length = 80)
        private String name;

        @Column(name = "course_score", nullable = false)
        private Integer score;

        protected Course() {
        }

        public Course(String name, Integer score) {
            this.name = name.strip();
            this.score = score;
        }

        public String getName() {
            return name;
        }

        public Integer getScore() {
            return score;
        }
    }
}
