package com.example.practice.student;

import java.time.LocalDateTime;
import java.util.List;

public record StudentResponse(
        Long id,
        String name,
        Integer age,
        String phone,
        StudentRequest.Address address,
        List<StudentRequest.Course> courses,
        LocalDateTime createdAt,
        LocalDateTime updatedAt) {
}
