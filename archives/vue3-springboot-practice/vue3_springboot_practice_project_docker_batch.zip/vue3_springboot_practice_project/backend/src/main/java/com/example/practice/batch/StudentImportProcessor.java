package com.example.practice.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.batch.infrastructure.item.ItemProcessor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.example.practice.student.StudentRequest;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;

@Component
public class StudentImportProcessor
        implements ItemProcessor<StudentCsvRow, StudentRequest> {

    private final Validator validator;

    public StudentImportProcessor(Validator validator) {
        this.validator = validator;
    }

    @Override
    public StudentRequest process(StudentCsvRow row) {
        List<StudentRequest.Course> courses = new ArrayList<>();
        if (StringUtils.hasText(row.course1())) {
            courses.add(new StudentRequest.Course(row.course1(), row.course1Score()));
        }
        if (StringUtils.hasText(row.course2())) {
            courses.add(new StudentRequest.Course(row.course2(), row.course2Score()));
        }

        StudentRequest request = new StudentRequest(
                row.name(),
                row.age(),
                row.phone(),
                new StudentRequest.Address(row.city(), row.street()),
                courses);

        var violations = validator.validate(request);
        if (!violations.isEmpty()) {
            String details = violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .collect(Collectors.joining("; "));
            throw new IllegalArgumentException(
                    "CSV 数据校验失败: " + row.name() + " -> " + details);
        }
        return request;
    }
}
