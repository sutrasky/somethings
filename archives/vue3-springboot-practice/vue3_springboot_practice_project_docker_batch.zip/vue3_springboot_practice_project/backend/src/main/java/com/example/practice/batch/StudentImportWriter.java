package com.example.practice.batch;

import org.springframework.batch.infrastructure.item.Chunk;
import org.springframework.batch.infrastructure.item.ItemWriter;
import org.springframework.stereotype.Component;

import com.example.practice.student.StudentRepository;
import com.example.practice.student.StudentRequest;
import com.example.practice.student.StudentService;

@Component
public class StudentImportWriter implements ItemWriter<StudentRequest> {

    private final StudentRepository repository;
    private final StudentService studentService;

    public StudentImportWriter(
            StudentRepository repository,
            StudentService studentService) {
        this.repository = repository;
        this.studentService = studentService;
    }

    @Override
    public void write(Chunk<? extends StudentRequest> chunk) {
        for (StudentRequest request : chunk) {
            String phone = request.phone() == null ? "" : request.phone().strip();
            if (!phone.isEmpty()
                    && repository.existsByNameAndPhone(request.name().strip(), phone)) {
                continue;
            }
            studentService.create(request);
        }
    }
}
