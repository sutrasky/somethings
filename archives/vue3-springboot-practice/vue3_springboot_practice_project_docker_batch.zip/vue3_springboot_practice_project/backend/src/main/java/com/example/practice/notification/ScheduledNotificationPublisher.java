package com.example.practice.notification;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(
        name = "practice.scheduling.enabled",
        havingValue = "true",
        matchIfMissing = true)
public class ScheduledNotificationPublisher {

    private final NotificationService notificationService;
    private final SimpMessagingTemplate messagingTemplate;
    private final String topic;

    public ScheduledNotificationPublisher(
            NotificationService notificationService,
            SimpMessagingTemplate messagingTemplate,
            @Value("${practice.scheduling.topic:/topic/notifications}") String topic) {
        this.notificationService = notificationService;
        this.messagingTemplate = messagingTemplate;
        this.topic = topic;
    }

    @Scheduled(
            fixedRateString = "${practice.scheduling.interval-ms:10000}",
            initialDelayString = "${practice.scheduling.initial-delay-ms:5000}")
    public void publishScheduledNotification() {
        NotificationMessage message = notificationService.scheduled(
                "这是 Spring @Scheduled 每 10 秒生成的主动推送。");
        messagingTemplate.convertAndSend(topic, message);
    }
}
