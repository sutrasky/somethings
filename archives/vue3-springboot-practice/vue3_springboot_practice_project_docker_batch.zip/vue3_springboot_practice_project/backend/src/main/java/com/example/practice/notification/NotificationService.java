package com.example.practice.notification;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedDeque;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class NotificationService {

    private static final int MAX_HISTORY = 30;

    private final ConcurrentLinkedDeque<NotificationMessage> history =
            new ConcurrentLinkedDeque<>();

    public NotificationService() {
        history.addFirst(new NotificationMessage(
                UUID.randomUUID().toString(),
                "WELCOME",
                "Messaging 已启用",
                "Vue 3 与 Spring Messaging 已建立连接。",
                "System",
                "STARTUP",
                LocalDateTime.now()));
    }

    public NotificationMessage fromClient(NotificationRequest request) {
        return add(
                "USER",
                StringUtils.hasText(request.title()) ? request.title().strip() : "前端消息",
                request.content().strip(),
                StringUtils.hasText(request.sender()) ? request.sender().strip() : "Vue 用户",
                "CLIENT_STOMP");
    }

    public NotificationMessage scheduled(String content) {
        return add(
                "SCHEDULE",
                "Spring Scheduling",
                content,
                "System",
                "SCHEDULED_TASK");
    }

    public NotificationMessage systemBroadcast(NotificationRequest request) {
        return add(
                "SYSTEM",
                StringUtils.hasText(request.title()) ? request.title().strip() : "系统广播",
                request.content().strip(),
                StringUtils.hasText(request.sender()) ? request.sender().strip() : "System",
                "REST_SIMP_MESSAGING_TEMPLATE");
    }

    public List<NotificationMessage> recent() {
        return history.stream().limit(MAX_HISTORY).toList();
    }

    private NotificationMessage add(
            String kind,
            String title,
            String content,
            String sender,
            String source) {
        NotificationMessage message = new NotificationMessage(
                UUID.randomUUID().toString(),
                kind,
                title,
                content,
                sender,
                source,
                LocalDateTime.now());
        history.addFirst(message);
        while (history.size() > MAX_HISTORY) {
            history.removeLast();
        }
        return message;
    }
}
