package com.example.practice.web;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.practice.batch.BatchExecutionView;
import com.example.practice.notification.NotificationMessage;
import com.example.practice.notification.NotificationService;
import com.example.practice.service.BatchJobService;
import com.example.practice.student.StudentResponse;
import com.example.practice.student.StudentService;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final StudentService studentService;
    private final BatchJobService batchJobService;
    private final NotificationService notificationService;

    public DashboardController(
            StudentService studentService,
            BatchJobService batchJobService,
            NotificationService notificationService) {
        this.studentService = studentService;
        this.batchJobService = batchJobService;
        this.notificationService = notificationService;
    }

    @GetMapping
    public DashboardView dashboard() {
        List<StudentResponse> students = studentService.findAll(null);
        int courseCount = students.stream()
                .mapToInt(student -> student.courses().size())
                .sum();
        double averageAge = students.stream()
                .mapToInt(StudentResponse::age)
                .average()
                .orElse(0);
        List<BatchExecutionView> executions = batchJobService.recentExecutions(1);

        return new DashboardView(
                students.size(),
                courseCount,
                Math.round(averageAge * 10.0) / 10.0,
                executions.isEmpty() ? null : executions.get(0),
                notificationService.recent().stream().limit(5).toList());
    }

    public record DashboardView(
            int totalStudents,
            int totalCourses,
            double averageAge,
            BatchExecutionView latestBatch,
            List<NotificationMessage> recentNotifications) {
    }
}
