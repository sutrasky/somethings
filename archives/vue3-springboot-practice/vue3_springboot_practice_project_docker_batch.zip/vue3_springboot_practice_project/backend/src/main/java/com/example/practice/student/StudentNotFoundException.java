package com.example.practice.student;

public class StudentNotFoundException extends RuntimeException {

    public StudentNotFoundException(Long id) {
        super("学生不存在，ID=" + id);
    }
}
