package com.example.practice.config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SpaForwardController {

    @GetMapping({
            "/students/**",
            "/notifications",
            "/exercises",
            "/batch"
    })
    public String forwardVueRoutes() {
        return "forward:/index.html";
    }
}
