package com.example.practice.batch;

import java.time.LocalDateTime;

import org.springframework.batch.core.job.JobExecution;
import org.springframework.batch.core.step.StepExecution;

public record BatchExecutionView(
        Long executionId,
        String jobName,
        String status,
        String exitCode,
        LocalDateTime startTime,
        LocalDateTime endTime,
        long readCount,
        long writeCount,
        long commitCount,
        String failureMessage) {

    public static BatchExecutionView from(JobExecution execution) {
        StepExecution step = execution.getStepExecutions().stream()
                .findFirst()
                .orElse(null);
        String failure = execution.getAllFailureExceptions().stream()
                .findFirst()
                .map(Throwable::getMessage)
                .orElse(null);
        return new BatchExecutionView(
                execution.getId(),
                execution.getJobInstance().getJobName(),
                execution.getStatus().name(),
                execution.getExitStatus().getExitCode(),
                execution.getStartTime(),
                execution.getEndTime(),
                step == null ? 0 : step.getReadCount(),
                step == null ? 0 : step.getWriteCount(),
                step == null ? 0 : step.getCommitCount(),
                failure);
    }
}
