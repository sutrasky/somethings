package com.example.practice.notification;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/notifications")
public class NotificationRestController {

    private final NotificationService notificationService;
    private final SimpMessagingTemplate messagingTemplate;

    public NotificationRestController(
            NotificationService notificationService,
            SimpMessagingTemplate messagingTemplate) {
        this.notificationService = notificationService;
        this.messagingTemplate = messagingTemplate;
    }

    @GetMapping("/recent")
    public List<NotificationMessage> recent() {
        return notificationService.recent();
    }

    @PostMapping("/system")
    @ResponseStatus(HttpStatus.CREATED)
    public NotificationMessage broadcast(@Valid @RequestBody NotificationRequest request) {
        NotificationMessage message = notificationService.systemBroadcast(request);
        messagingTemplate.convertAndSend("/topic/system", message);
        return message;
    }
}
