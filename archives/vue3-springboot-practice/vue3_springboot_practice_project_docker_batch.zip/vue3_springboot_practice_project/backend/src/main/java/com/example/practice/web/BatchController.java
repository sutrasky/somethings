package com.example.practice.web;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.practice.batch.BatchExecutionView;
import com.example.practice.config.StudentBatchConfig;
import com.example.practice.service.BatchJobService;

@RestController
@RequestMapping("/api/batch")
public class BatchController {

    private final BatchJobService batchJobService;

    public BatchController(BatchJobService batchJobService) {
        this.batchJobService = batchJobService;
    }

    @GetMapping("/jobs")
    public List<Map<String, String>> jobs() {
        return List.of(Map.of(
                "jobName", StudentBatchConfig.STUDENT_IMPORT_JOB,
                "stepName", StudentBatchConfig.STUDENT_IMPORT_STEP,
                "input", "classpath:batch/students-import.csv"));
    }

    @PostMapping("/student-import")
    @ResponseStatus(HttpStatus.CREATED)
    public BatchExecutionView launchStudentImport() {
        return batchJobService.launchStudentImport();
    }

    @GetMapping("/executions")
    public List<BatchExecutionView> executions(
            @RequestParam(defaultValue = "10") int limit) {
        return batchJobService.recentExecutions(limit);
    }

    @GetMapping("/executions/{id}")
    public BatchExecutionView execution(@PathVariable long id) {
        return batchJobService.findExecution(id);
    }
}
