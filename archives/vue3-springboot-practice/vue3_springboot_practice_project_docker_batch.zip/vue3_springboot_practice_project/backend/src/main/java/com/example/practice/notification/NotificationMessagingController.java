package com.example.practice.notification;

import java.util.List;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.stereotype.Controller;

import jakarta.validation.Valid;

@Controller
public class NotificationMessagingController {

    private final NotificationService notificationService;

    public NotificationMessagingController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @MessageMapping("/notifications/send")
    @SendTo("/topic/notifications")
    public NotificationMessage receiveFromClient(
            @Valid NotificationRequest request) {
        return notificationService.fromClient(request);
    }

    @SubscribeMapping("/notifications/init")
    public List<NotificationMessage> initialNotifications() {
        return notificationService.recent();
    }
}
