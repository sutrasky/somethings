package com.example.practice.student;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public StudentResponse create(StudentRequest request) {
        Student saved = repository.save(new Student(
                request.name(),
                request.age(),
                request.phone(),
                request.address().city(),
                request.address().street(),
                toCourses(request.courses())));
        return toResponse(saved);
    }

    @Transactional
    public StudentResponse update(Long id, StudentRequest request) {
        Student student = findEntity(id);
        student.replace(
                request.name(),
                request.age(),
                request.phone(),
                request.address().city(),
                request.address().street(),
                toCourses(request.courses()));
        return toResponse(student);
    }

    public List<StudentResponse> findAll(String query) {
        List<Student> students = query == null || query.isBlank()
                ? repository.findAll()
                : repository.findByNameContainingIgnoreCaseOrderByIdDesc(query.strip());
        return students.stream()
                .sorted((left, right) -> Long.compare(right.getId(), left.getId()))
                .map(this::toResponse)
                .toList();
    }

    public StudentResponse findById(Long id) {
        return toResponse(findEntity(id));
    }

    @Transactional
    public void delete(Long id) {
        Student student = findEntity(id);
        repository.delete(student);
    }

    public long count() {
        return repository.count();
    }

    private Student findEntity(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new StudentNotFoundException(id));
    }

    private List<Student.Course> toCourses(List<StudentRequest.Course> courses) {
        if (courses == null) {
            return List.of();
        }
        return courses.stream()
                .map(course -> new Student.Course(course.name(), course.score()))
                .toList();
    }

    private StudentResponse toResponse(Student student) {
        StudentRequest.Address address =
                new StudentRequest.Address(student.getCity(), student.getStreet());
        List<StudentRequest.Course> courses = student.getCourses().stream()
                .map(course -> new StudentRequest.Course(course.getName(), course.getScore()))
                .toList();
        return new StudentResponse(
                student.getId(),
                student.getName(),
                student.getAge(),
                student.getPhone(),
                address,
                courses,
                student.getCreatedAt(),
                student.getUpdatedAt());
    }
}
