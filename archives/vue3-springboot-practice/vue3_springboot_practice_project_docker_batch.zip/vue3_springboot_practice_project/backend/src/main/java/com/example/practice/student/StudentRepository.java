package com.example.practice.student;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {

    List<Student> findByNameContainingIgnoreCaseOrderByIdDesc(String name);

    boolean existsByNameAndPhone(String name, String phone);
}
