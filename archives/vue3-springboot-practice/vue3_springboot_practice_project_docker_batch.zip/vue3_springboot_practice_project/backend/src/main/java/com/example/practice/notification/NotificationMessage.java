package com.example.practice.notification;

import java.time.LocalDateTime;

public record NotificationMessage(
        String id,
        String kind,
        String title,
        String content,
        String sender,
        String source,
        LocalDateTime createdAt) {
}
