package com.example.practice.config;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.ChunkOrientedStepBuilder;
import org.springframework.batch.infrastructure.item.file.FlatFileItemReader;
import org.springframework.batch.infrastructure.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.transaction.PlatformTransactionManager;

import com.example.practice.batch.StudentCsvRow;
import com.example.practice.batch.StudentImportProcessor;
import com.example.practice.batch.StudentImportWriter;
import com.example.practice.student.StudentRequest;

@Configuration
public class StudentBatchConfig {

    public static final String STUDENT_IMPORT_JOB = "studentImportJob";
    public static final String STUDENT_IMPORT_STEP = "studentImportStep";

    @Bean
    public FlatFileItemReader<StudentCsvRow> studentCsvReader(
            @Value("${practice.batch.input-file:classpath:batch/students-import.csv}")
            Resource resource) {
        return new FlatFileItemReaderBuilder<StudentCsvRow>()
                .name("studentCsvReader")
                .resource(resource)
                .encoding("UTF-8")
                .linesToSkip(1)
                .strict(true)
                .delimited()
                .delimiter(",")
                .names(
                        "name",
                        "age",
                        "phone",
                        "city",
                        "street",
                        "course1",
                        "course1Score",
                        "course2",
                        "course2Score")
                .fieldSetMapper(fieldSet -> new StudentCsvRow(
                        fieldSet.readString("name"),
                        fieldSet.readInt("age"),
                        fieldSet.readString("phone"),
                        fieldSet.readString("city"),
                        fieldSet.readString("street"),
                        fieldSet.readString("course1"),
                        fieldSet.readInt("course1Score"),
                        fieldSet.readString("course2"),
                        fieldSet.readInt("course2Score")))
                .build();
    }

    @Bean
    public Step studentImportStep(
            JobRepository jobRepository,
            PlatformTransactionManager transactionManager,
            FlatFileItemReader<StudentCsvRow> studentCsvReader,
            StudentImportProcessor studentImportProcessor,
            StudentImportWriter studentImportWriter) {
        return new ChunkOrientedStepBuilder<StudentCsvRow, StudentRequest>(
                STUDENT_IMPORT_STEP, jobRepository, 5)
                .transactionManager(transactionManager)
                .reader(studentCsvReader)
                .processor(studentImportProcessor)
                .writer(studentImportWriter)
                .build();
    }

    @Bean
    public Job studentImportJob(JobRepository jobRepository, Step studentImportStep) {
        return new JobBuilder(STUDENT_IMPORT_JOB, jobRepository)
                .start(studentImportStep)
                .build();
    }
}
