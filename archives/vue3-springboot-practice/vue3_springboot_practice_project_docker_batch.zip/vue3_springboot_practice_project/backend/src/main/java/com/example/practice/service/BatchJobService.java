package com.example.practice.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.JobExecution;
import org.springframework.batch.core.job.parameters.JobParametersBuilder;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.practice.batch.BatchExecutionView;
import com.example.practice.config.StudentBatchConfig;

@Service
@SuppressWarnings("deprecation")
public class BatchJobService {

    private final JobOperator jobOperator;
    private final Job studentImportJob;
    private final JobRepository jobRepository;

    public BatchJobService(
            JobOperator jobOperator,
            @Qualifier("studentImportJob") Job studentImportJob,
            JobRepository jobRepository) {
        this.jobOperator = jobOperator;
        this.studentImportJob = studentImportJob;
        this.jobRepository = jobRepository;
    }

    public BatchExecutionView launchStudentImport() {
        try {
            var parameters = new JobParametersBuilder()
                    .addLong("run.id", System.nanoTime())
                    .toJobParameters();
            JobExecution execution = jobOperator.start(studentImportJob, parameters);
            return BatchExecutionView.from(execution);
        }
        catch (Exception ex) {
            throw new IllegalStateException(
                    "启动学生导入 Batch Job 失败: " + ex.getMessage(), ex);
        }
    }

    public List<BatchExecutionView> recentExecutions(int limit) {
        int safeLimit = Math.max(1, Math.min(limit, 50));
        List<JobExecution> executions = new ArrayList<>();
        try {
            List<Long> instanceIds = jobOperator.getJobInstances(
                    StudentBatchConfig.STUDENT_IMPORT_JOB, 0, 20);
            for (Long instanceId : instanceIds) {
                for (Long executionId : jobOperator.getExecutions(instanceId)) {
                    executions.add(jobRepository.getJobExecution(executionId));
                }
            }
        }
        catch (Exception ex) {
            throw new IllegalStateException("读取 Batch 执行历史失败", ex);
        }
        return executions.stream()
                .sorted(Comparator.comparing(JobExecution::getId).reversed())
                .limit(safeLimit)
                .map(BatchExecutionView::from)
                .toList();
    }

    public BatchExecutionView findExecution(long executionId) {
        JobExecution execution = jobRepository.getJobExecution(executionId);
        if (execution == null) {
            throw new IllegalArgumentException(
                    "Batch execution 不存在: " + executionId);
        }
        return BatchExecutionView.from(execution);
    }
}
