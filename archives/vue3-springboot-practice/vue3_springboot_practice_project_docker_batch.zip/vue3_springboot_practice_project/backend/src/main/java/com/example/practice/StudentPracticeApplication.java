package com.example.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class StudentPracticeApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentPracticeApplication.class, args);
    }
}
