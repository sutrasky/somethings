# Vue 3 + Spring Boot 4.1.2 + MySQL Student Practice Lab

这是一个完整可运行的教学项目，在原有学生管理能力上增加了：

- Docker Compose 管理 MySQL 8.4。
- 项目根目录 `data/` 持久化数据库。
- Spring Data JPA 学生管理。
- Spring Boot 4.1.2 + Spring Framework 7 + Hibernate 7。
- Jackson 3（`tools.jackson.*`）。
- Spring Batch 6 CSV 学生导入。
- Batch Job/Step 执行历史持久化到 MySQL。
- REST Dashboard、Batch 管理与学生 CRUD API。
- 嵌套地址对象和课程数组传输。
- Vue Router 学生列表、新建、编辑、详情页面。
- Spring Messaging + STOMP + WebSocket。
- `@MessageMapping`、`@SendTo`、`@SubscribeMapping`、`SimpMessagingTemplate`。
- `@EnableScheduling` + `@Scheduled` 每 10 秒主动推送。
- 六道可勾选练习，包括 Batch。

> 数据库使用 `root/root` 只是为了本地教学。生产环境必须使用独立用户、
> 强密码、环境变量或密钥管理系统。

---

## 1. 项目结构

```text
vue3_springboot_practice_project/
├── docker-compose.yml
├── data/
│   └── .gitkeep
├── .gitignore
├── backend/
│   ├── pom.xml
│   ├── mvnw / mvnw.cmd
│   └── src/
│       ├── main/java/com/example/practice/
│       │   ├── student/        学生实体、Repository、Service、Controller
│       │   ├── batch/          CSV Row、Processor、Writer、执行 DTO
│       │   ├── notification/   消息处理、定时推送、REST 广播
│       │   ├── config/         WebSocket、Batch Job、CORS、SPA fallback
│       │   └── common/         统一异常返回
│       ├── main/resources/
│       │   ├── application.properties
│       │   └── static/         Vue 构建产物
│       └── test/               H2 测试
├── frontend/
│   ├── package.json
│   ├── package-lock.json
│   ├── vite.config.js
│   ├── scripts/websocket-smoke.mjs
│   └── src/
│       ├── router/             Vue Router
│       ├── views/              列表、表单、详情、消息、练习
│       │   └── BatchView.vue   Batch 管理页面
│       ├── composables/        STOMP 全局连接
│       └── api/client.js       REST 请求封装
└── docs/
    ├── 01-getting-started.md
    ├── 02-architecture.md
    ├── 03-messaging-scheduling.md
    ├── 04-exercises.md
    ├── 05-api.md
    ├── 06-troubleshooting.md
    ├── 07-boot4-migration.md
    └── 08-batch-processing.md
```

---

## 2. 环境要求

- JDK 17 或更高版本。
- Eclipse IDE for Enterprise Java and Web Developers。
- Docker Desktop。
- Node.js 20.19+ 或 22.12+。
- npm 10+。

检查：

```powershell
java -version
docker --version
docker compose version
node -v
npm -v
```

Docker Desktop 必须保持运行，否则 MySQL 容器无法启动。

---

## 3. Step by Step 启动

### 第一步：启动 MySQL

在项目根目录执行：

```powershell
cd D:\codex_wokspace\vue3_springboot_practice_project
docker compose up -d
```

检查健康状态：

```powershell
docker compose ps
```

期望：

```text
student-mysql   Up ... (healthy)
```

MySQL 参数：

| 配置 | 值 |
| --- | --- |
| Host | `localhost` |
| Port | `3306` |
| Database | `student_db` |
| Username | `root` |
| Password | `root` |

数据目录：

```text
./data
```

`docker compose down` 只删除容器和网络，不删除项目根目录 `data/`。

### 第二步：在 Eclipse 启动后端

1. Eclipse 选择 `File -> Import...`。
2. 选择 `Maven -> Existing Maven Projects`。
3. 导入 `backend` 目录。
4. 等待 Maven 下载依赖。
5. 打开：

```text
backend/src/main/java/com/example/practice/StudentPracticeApplication.java
```

6. 右键 `Run As -> Java Application`。

控制台看到：

```text
Tomcat started on port 8080
Started StudentPracticeApplication
```

验证 REST API：

```text
http://localhost:8080/api/students
```

第一次启动会自动创建两张表：

- `students`
- `student_courses`

如果数据库为空，会插入张三和李四两条示例数据。

### 第三步：启动 Vue 3

打开另一个终端：

```powershell
cd D:\codex_wokspace\vue3_springboot_practice_project\frontend
npm install
npm run dev
```

看到：

```text
VITE ready
Local: http://localhost:5173/
```

浏览器访问：

```text
http://localhost:5173
```

### 第四步：验证运行

页面应包含：

- 学生列表。
- “新增学生”按钮。
- 学生详情和完整 JSON。
- 消息中心，右上角显示 `STOMP ONLINE`。
- 六道练习清单（含 Batch）。
- 消息中心每 10 秒自动增加一条 `SCHEDULE` 消息。

---

## 4. 使用 Maven Wrapper

如果 Eclipse 已能运行，可以跳过命令行启动。

命令行方式：

```powershell
cd backend
.\mvnw.cmd spring-boot:run
```

运行测试：

```powershell
.\mvnw.cmd test
```

测试使用 H2 内存数据库，不会修改 Docker MySQL 中的数据。

---

## 5. Vue Router 页面

| URL | 页面 |
| --- | --- |
| `/` | 学生列表和姓名搜索 |
| `/students/new` | 新增学生 |
| `/students/:id` | 学生详情 |
| `/students/:id/edit` | 编辑学生 |
| `/notifications` | STOMP 实时消息中心 |
| `/exercises` | 六道练习清单 |
| `/batch` | Spring Batch 管理与执行历史 |

生产构建后直接刷新 `/students/3`，Spring Boot 会通过
`SpaForwardController` 返回 `index.html`，再交给 Vue Router 处理。

---

## 6. 复杂对象传输

新增或更新学生的 JSON：

```json
{
  "name": "王五",
  "age": 22,
  "phone": "13800000003",
  "address": {
    "city": "南京",
    "street": "鼓楼区中山路 300 号"
  },
  "courses": [
    {
      "name": "Spring Messaging",
      "score": 96
    },
    {
      "name": "MySQL",
      "score": 89
    }
  ]
}
```

对应 Java 请求对象：

```java
public record StudentRequest(
    String name,
    Integer age,
    String phone,
    Address address,
    List<Course> courses
) {
    public record Address(String city, String street) {}
    public record Course(String name, Integer score) {}
}
```

数据库映射：

```text
students
  ├── id
  ├── name
  ├── age
  ├── phone
  ├── city
  ├── street
  └── timestamps

student_courses
  ├── student_id -> students.id
  ├── course_name
  └── course_score
```

---

## 7. REST API

| 方法 | 路径 | 作用 |
| --- | --- | --- |
| `GET` | `/api/students` | 学生列表 |
| `GET` | `/api/students?query=张` | 按姓名搜索 |
| `GET` | `/api/students/{id}` | 学生详情 |
| `POST` | `/api/students` | 新增学生 |
| `PUT` | `/api/students/{id}` | 更新学生 |
| `DELETE` | `/api/students/{id}` | 删除学生 |
| `GET` | `/api/notifications/recent` | 最近消息 |
| `POST` | `/api/notifications/system` | REST 主动广播 |
| `GET` | `/api/dashboard` | 学生、课程、最近 Batch、通知汇总 |
| `GET` | `/api/batch/jobs` | Batch Job 元数据 |
| `POST` | `/api/batch/student-import` | 启动 CSV 导入 Job |
| `GET` | `/api/batch/executions` | 查询 Batch 执行历史 |
| `GET` | `/api/batch/executions/{id}` | 查询单次执行 |

详细请求示例见 [API 文档](docs/05-api.md)。

---

### 7.1 Spring Batch 处理流程

```text
students-import.csv
  -> FlatFileItemReader
  -> StudentImportProcessor（Bean Validation）
  -> Chunk ItemWriter
  -> StudentService
  -> MySQL students / student_courses
```

Job 名称：

```text
studentImportJob
```

Step 名称：

```text
studentImportStep
```

Chunk 大小：

```text
5
```

每次 REST 启动都会生成唯一参数 `run.id`，因此同一 Job 可以重复运行。
Writer 使用“姓名 + 电话”判断重复，重复执行不会再次插入相同 CSV 学生。

Batch 元数据保存在：

```text
BATCH_JOB_INSTANCE
BATCH_JOB_EXECUTION
BATCH_JOB_EXECUTION_PARAMS
BATCH_STEP_EXECUTION
BATCH_*_CONTEXT
```

配置：

```properties
spring.batch.job.enabled=false
spring.batch.jdbc.initialize-schema=always
```

`spring.batch.job.enabled=false` 表示应用启动时不会自动执行 Job，
必须在 Vue 页面或 REST 接口中手动触发。

详见 [Spring Batch 文档](docs/08-batch-processing.md)。

## 8. Spring Messaging 与 Scheduling

WebSocket 端点：

```text
ws://localhost:5173/ws
```

开发时 Vite 代理到：

```text
ws://localhost:8080/ws
```

STOMP 目的地：

| 类型 | 目的地 |
| --- | --- |
| 前端发送 | `/app/notifications/send` |
| 初始化数据 | `/app/notifications/init` |
| 普通消息 Topic | `/topic/notifications` |
| 系统广播 Topic | `/topic/system` |

关键注解：

- `@MessageMapping`：接收 STOMP 消息。
- `@SendTo`：把返回值广播到 Topic。
- `@SubscribeMapping`：Vue 订阅初始化目的地时返回历史消息。
- `SimpMessagingTemplate`：REST 或定时任务主动推送。
- `@EnableScheduling`：开启 Spring 调度。
- `@Scheduled`：每 10 秒推送系统通知。

完整数据流见 [Messaging 文档](docs/03-messaging-scheduling.md)。

---

## 9. Vue STOMP 客户端

前端使用：

```js
import { Client } from "@stomp/stompjs";
```

全局组合函数：

```text
frontend/src/composables/useNotifications.js
```

它负责：

1. 建立 `/ws` 连接。
2. 订阅 `/topic/notifications`。
3. 订阅 `/topic/system`。
4. 订阅初始化目的地 `/app/notifications/init`。
5. 自动重连。
6. 消息去重并维护最近 50 条。
7. 向 `/app/notifications/send` 发布消息。

---

## 10. 验证 MySQL 持久化

### 10.1 新增测试学生

在 Vue 页面新增一名学生，例如：

```text
姓名：持久化验证
城市：上海
课程：MySQL 95
```

### 10.2 停止容器和后端

停止 Eclipse 后端，然后：

```powershell
docker compose down
```

注意：不要删除 `data/`。

### 10.3 重新启动

```powershell
docker compose up -d
```

等待 healthy，再启动 Spring Boot。刷新 Vue 页面，刚新增的学生仍然存在。

也可以直接查询：

```powershell
docker exec student-mysql mysql -uroot -proot -e "USE student_db; SELECT * FROM students; SELECT * FROM student_courses;"
```

---

## 11. 生产构建

```powershell
cd frontend
npm run build
```

Vite 输出到：

```text
backend/src/main/resources/static/
```

重新启动后端后，可以直接访问：

```text
http://localhost:8080
```

这时不需要运行 Vite。

每次修改 Vue 后，如果希望 8080 显示新版本，需要重新执行 `npm run build`。

---

## 12. 自动测试

后端：

```powershell
cd backend
.\mvnw.cmd test
```

覆盖：

- 种子学生。
- 复杂对象创建和详情。
- PUT/DELETE。
- 嵌套字段校验。
- SimpMessagingTemplate REST 广播。
- Vue Router 生产 fallback。
- Spring Batch CSV 导入、执行历史和重复行去重。

前端构建：

```powershell
cd frontend
npm run build
```

STOMP 冒烟测试：

```powershell
$env:WS_URL="ws://localhost:8080/ws"
npm run ws:smoke
```

成功输出：

```text
STOMP OK: Smoke Test / Vue STOMP smoke ...
```

---

## 13. 停止项目

停止 Vue：

```text
在 npm run dev 的终端按 Ctrl+C
```

停止 Spring Boot：

```text
Eclipse Console 点击红色停止按钮
```

停止 MySQL：

```powershell
docker compose down
```

`data/` 中的数据仍会保留。

---

## 14. Spring Boot 4.1.2 适配说明

本项目使用 Boot 4 的模块化 Starter：

```xml
spring-boot-starter-webmvc
spring-boot-starter-jackson
spring-boot-starter-batch-jdbc
spring-boot-starter-webmvc-test
```

Boot 4 的主要差异：

- Web MVC 使用 `spring-boot-starter-webmvc`。
- JSON 默认使用 Jackson 3，包名为 `tools.jackson.*`。
- MockMvc test 自动配置包变为
  `org.springframework.boot.webmvc.test.autoconfigure`。
- Spring Framework 升级为 7，Hibernate 升级为 7。
- Spring Batch 升级为 6。
- Batch ItemReader/Writer 移到
  `org.springframework.batch.infrastructure.item.*`。
- Batch JDBC Repository 使用 `spring-boot-starter-batch-jdbc`。
- Jackson 3 不再接受旧属性
  `spring.jackson.serialization.write-dates-as-timestamps`。

详见 [Boot 4 迁移说明](docs/07-boot4-migration.md)。

---

## 15. 安全说明

当前配置：

```properties
DB_USERNAME=root
DB_PASSWORD=root
```

只适合本地开发和学习。

生产环境应：

- 创建只有业务权限的数据库用户。
- 使用强密码和密钥管理。
- 关闭 root 远程登录。
- 使用 HTTPS/WSS。
- 限制 WebSocket Origin。
- 增加 Spring Security 和 CSRF 策略。
- 使用 Flyway/Liquibase 管理数据库结构。

---

## 16. 文档

- [启动与目录说明](docs/01-getting-started.md)
- [架构与请求链路](docs/02-architecture.md)
- [Spring Messaging 与 Scheduling](docs/03-messaging-scheduling.md)
- [六道练习题](docs/04-exercises.md)
- [REST API](docs/05-api.md)
- [排错指南](docs/06-troubleshooting.md)
- [Boot 4.1.2 迁移说明](docs/07-boot4-migration.md)
- [Spring Batch Processing](docs/08-batch-processing.md)
