# Spring Boot 4.1.2 迁移说明

## 1. 版本

```text
Spring Boot 4.1.2
Spring Framework 7
Hibernate ORM 7
Spring Batch 6.0.x
Jackson 3
Java 17+
```

本次升级实际使用 Java 25 编译和运行，项目目标版本仍是 Java 17。

## 2. 模块化 Starter

Boot 4 推荐更明确地选择 WebMVC 与 Jackson：

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-webmvc</artifactId>
</dependency>
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-jackson</artifactId>
</dependency>
```

不再依赖旧 `spring-boot-starter-web` 一个聚合入口。

## 3. Jackson 3

旧：

```java
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
```

新：

```java
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.JsonNode;
```

旧属性：

```properties
spring.jackson.serialization.write-dates-as-timestamps=false
```

在 Jackson 3 中该枚举不存在，会导致 JacksonProperties 绑定失败。
本项目已删除该属性。Java Time 默认以 ISO 字符串输出。

## 4. MockMvc 自动配置

Boot 4 拆分测试 Starter：

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-webmvc-test</artifactId>
  <scope>test</scope>
</dependency>
```

导入变化：

```java
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
```

## 5. Spring Batch 6

Batch JDBC Starter：

```xml
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-batch-jdbc</artifactId>
</dependency>
```

Item API 包变化：

```java
import org.springframework.batch.infrastructure.item.ItemProcessor;
import org.springframework.batch.infrastructure.item.ItemWriter;
import org.springframework.batch.infrastructure.item.Chunk;
import org.springframework.batch.infrastructure.item.file.FlatFileItemReader;
```

新 Chunk Step Builder：

```java
new ChunkOrientedStepBuilder<StudentCsvRow, StudentRequest>(
        "studentImportStep", jobRepository, 5)
    .transactionManager(transactionManager)
    .reader(reader)
    .processor(processor)
    .writer(writer)
    .build();
```

相比旧的 `chunk(size, txManager)`，新 API 避免了 Batch 6 中的 legacy
chunk implementation。

## 6. JobRepository 与 JobOperator

项目使用：

```java
JobOperator.start(job, parameters)
```

执行历史通过 `JobRepository` 和 `JobOperator` 查询。

## 7. Batch Schema

```properties
spring.batch.jdbc.initialize-schema=always
spring.batch.job.enabled=false
```

已在 MySQL 8.4 上验证：

- 第一次启动创建 `BATCH_*` 表。
- 停止 MySQL 和后端。
- 再次启动不会因表已存在而失败。
- 原有 JobExecution 历史仍可查询。

## 8. 测试迁移

测试已适配：

- `AutoConfigureMockMvc` 新包。
- Jackson 3 ObjectMapper。
- Batch 6 新 Item API。
- H2 Batch JDBC Schema。

当前结果：

```text
Tests run: 7, Failures: 0, Errors: 0
BUILD SUCCESS
```
