# 六道练习

页面 `/exercises` 提供可勾选进度，保存在浏览器 `localStorage`。

## 练习 1：MySQL 持久化

步骤：

1. 新增学生“持久化练习”。
2. 停止 Spring Boot。
3. 执行 `docker compose down`。
4. 执行 `docker compose up -d`。
5. 等待 MySQL healthy。
6. 重启 Spring Boot。
7. 刷新 Vue 页面。

预期：

- 学生仍然存在。
- `data/` 中仍是原来的 MySQL 文件。

SQL 验证：

```powershell
docker exec student-mysql mysql -uroot -proot -e "USE student_db; SELECT * FROM students;"
```

## 练习 2：复杂对象传输

新增学生时：

- 填写城市和街道。
- 至少添加两门课程。
- 提交后进入详情页。

预期：

- 地址以 `address` 嵌套对象返回。
- 课程以 `courses` 数组返回。
- 页面完整 JSON 包含这两个结构。

## 练习 3：嵌套校验

步骤：

- 城市留空。
- 街道留空。
- 一门课程成绩填 `101`。
- 提交。

预期：

- HTTP 400。
- 错误键包含：
  - `address.city`
  - `address.street`
  - `courses[0].score`

学习点：

```java
@Valid @NotNull Address address
@Valid List<Course> courses
```

嵌套对象必须继续加 `@Valid`，否则内部约束不会生效。

## 练习 4：搜索、编辑、删除

搜索：

```text
GET /api/students?query=张
```

编辑：

```text
PUT /api/students/{id}
```

删除：

```text
DELETE /api/students/{id}
```

预期：

- 编辑后详情立即变化。
- 删除后列表不再包含该学生。
- 浏览器 Network 分别出现 GET、PUT、DELETE。

## 练习 5：观察消息通信

1. 打开两个 `/notifications` 标签页。
2. 两个标签页都显示 STOMP ONLINE。
3. 在一个页面用 STOMP 发送消息。
4. 两个页面都应收到。
5. 等待 20 秒。
6. 两个页面都应收到至少两条 `SCHEDULE` 消息。

再点击“REST → /topic/system”：

- 消息先走 REST。
- 后端调用 `SimpMessagingTemplate`。
- 两个页面通过 `/topic/system` 收到广播。

最终思考：

```text
为什么浏览器发送的消息会回到两个浏览器？
```

答案：后端通过 `@SendTo` 把处理结果发布到共享 Topic。

## 练习 6：Spring Batch CSV 导入

打开 `/batch`：

1. 点击“启动导入 Job”。
2. 查看 `COMPLETED`、read/write/commit 数量。
3. 再次点击。
4. 对比学生总人数。

预期：

- 第一次读取并写入 3 名学生。
- 第二次仍读取 3 条。
- 因为 Writer 去重，学生总数不再次增加。
- Batch 执行历史增加一条。

SQL：

```powershell
docker exec student-mysql mysql -uroot -proot -e "
USE student_db;
SELECT * FROM BATCH_JOB_EXECUTION;
SELECT * FROM BATCH_STEP_EXECUTION;
"
```
