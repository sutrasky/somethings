# 架构与请求链路

## 1. 总体架构

```mermaid
flowchart LR
    Browser[Vue 3 Browser]
    Vite[Vite :5173]
    Spring[Spring Boot :8080]
    JPA[JPA / Hibernate]
    MySQL[(MySQL 8.4)]
    Broker[Simple Message Broker]
    Scheduler[Spring Scheduling]
    Batch[Spring Batch]

    Browser -->|REST /api| Vite
    Browser -->|STOMP websocket| Vite
    Vite --> Spring
    Spring --> JPA --> MySQL
    Spring --> Broker
    Scheduler --> Broker
    Batch --> JPA
    Broker -->|/topic/*| Browser
```

## 2. 后端分层

```text
StudentController
  -> StudentService
  -> StudentRepository
  -> Student Entity
  -> MySQL
```

职责：

- Controller：HTTP 参数、状态码。
- DTO：前端 JSON 结构。
- Service：业务和事务。
- Repository：JPA 数据访问。
- Entity：数据库映射。

## 3. 实体和表

`Student`：

```text
students
├── id
├── name
├── age
├── phone
├── city
├── street
├── created_at
└── updated_at
```

课程使用 `@ElementCollection`：

```text
student_courses
├── student_id
├── course_name
└── course_score
```

一个学生可以有多个课程记录。

## 4. 创建学生链路

```mermaid
sequenceDiagram
    participant V as Vue Form
    participant C as StudentController
    participant S as StudentService
    participant R as StudentRepository
    participant DB as MySQL

    V->>C: POST /api/students JSON
    C->>S: create(StudentRequest)
    S->>S: 转换 Course DTO
    S->>R: save(Student)
    R->>DB: INSERT students
    R->>DB: INSERT student_courses
    S-->>C: StudentResponse
    C-->>V: 201 Created JSON
    V->>V: Router.push(/students/:id)
```

## 5. 查询详情链路

```text
GET /api/students/3
  -> StudentService.findById
  -> repository.findById
  -> Student Entity
  -> StudentResponse
  -> Vue StudentDetailView
```

`@Transactional(readOnly=true)` 允许 Hibernate 在事务中读取懒加载课程集合。

## 6. Vue Router

```text
/                      StudentsView
/students/new          StudentFormView
/students/:id          StudentDetailView
/students/:id/edit     StudentFormView
/notifications         NotificationsView
/exercises             ExercisesView
```

History 模式需要服务器 fallback。`SpaForwardController` 对
`/students/**`、`/notifications`、`/exercises` 返回 `index.html`。

## 7. 通知架构

```text
Vue STOMP
  -> /app/notifications/send
  -> @MessageMapping
  -> NotificationService
  -> @SendTo /topic/notifications
  -> 所有订阅者
```

初始化订阅：

```text
Vue SUBSCRIBE /app/notifications/init
  -> @SubscribeMapping
  -> 最近通知列表
```

后端主动广播：

```text
REST Controller 或 @Scheduled
  -> SimpMessagingTemplate
  -> /topic/system 或 /topic/notifications
```

## 8. 前端状态

`useNotifications.js` 是模块级单例组合函数：

- `messages`：最近消息。
- `connected`：STOMP 连接状态。
- `client`：唯一 STOMP 客户端。
- App 挂载时连接，卸载时断开。

这样切换 Vue Router 页面不会重复建立多个 WebSocket。

## 9. Batch 与 REST 汇总

```text
POST /api/batch/student-import
  -> BatchJobService
  -> JobOperator
  -> studentImportJob
  -> studentImportStep
  -> CSV Reader -> Processor -> MySQL Writer
  -> JobRepository
  -> REST 返回 Execution
```

`GET /api/dashboard` 汇总：

- 学生数。
- 课程数。
- 平均年龄。
- 最近一次 Batch 状态。
- 最近通知。
