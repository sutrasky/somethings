# 排错指南

## 1. Docker Engine 未运行

错误：

```text
cannot connect to the Docker API
```

处理：

- 打开 Docker Desktop。
- 等待 Engine Running。
- 再执行 `docker compose up -d`。

## 2. MySQL 不是 healthy

```powershell
docker compose logs mysql
docker compose ps
```

常见原因：

- 3306 被本机 MySQL 占用。
- `data/` 来自更高版本 MySQL。
- 磁盘空间不足。
- 密码环境变量与已有数据不匹配。

## 3. Spring Boot 无法连接 MySQL

检查：

```text
localhost:3306
student_db
root/root
```

可执行：

```powershell
docker exec -it student-mysql mysql -uroot -proot
```

## 4. 8080 被占用

```powershell
Get-NetTCPConnection -LocalPort 8080 -State Listen
```

先停止旧 Spring Boot 项目。

也可以临时切换：

```powershell
$env:SERVER_PORT="8081"
.\mvnw.cmd spring-boot:run
```

同时设置前端：

```powershell
$env:VITE_BACKEND_URL="http://localhost:8081"
npm run dev
```

## 5. Vue 页面没有数据

检查：

```text
http://localhost:8080/api/students
```

如果不返回 JSON：

- 后端未启动。
- MySQL 未启动。
- 数据库认证错误。

## 6. STOMP 一直 RECONNECTING

检查浏览器 Console 和 Network：

- `/ws` 是否 101 Switching Protocols。
- Vite 是否运行。
- Spring Boot WebSocket 是否启动。
- 是否使用正确端口。

手动测试：

```powershell
cd frontend
$env:WS_URL="ws://localhost:8080/ws"
npm run ws:smoke
```

## 7. 生产构建后刷新子路由 404

本项目的 `SpaForwardController` 负责转发：

```text
/students/**
/notifications
/exercises
```

如果新增 Vue Router 顶层路径，需要同步添加到该 Controller。

## 8. 修改 Vue 后 8080 没变化

重新构建：

```powershell
cd frontend
npm run build
```

然后刷新。

## 9. 清空数据库

普通停止不需要清空：

```powershell
docker compose down
```

如果确实需要从空数据库开始：

1. 在 Docker Desktop 中删除 `student-mysql`。
2. 备份后自行清理 `data/`。
3. 重新 `docker compose up -d`。

清理 `data/` 会永久删除本地教学数据。

## 10. Vue Router 页面刷新

开发模式 Vite 会自动回退。

生产模式由 Spring Boot fallback 处理。

不要使用静态文件服务器直接托管 `dist`，除非也配置 SPA fallback。

## 11. Boot 4 中找不到 AutoConfigureMockMvc

Boot 4 的包已经变化：

```java
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
```

并需要：

```xml
spring-boot-starter-webmvc-test
```

## 12. Jackson 3 找不到 com.fasterxml ObjectMapper

Boot 4 默认使用 Jackson 3：

```java
import tools.jackson.databind.ObjectMapper;
```

不要再配置 Jackson 2 专属的旧枚举属性。

## 13. Batch 启动时报 BATCH_* 表不存在

确认：

```properties
spring.batch.jdbc.initialize-schema=always
```

依赖：

```xml
spring-boot-starter-batch-jdbc
```

## 14. Batch Job 应用启动时自动执行

确认：

```properties
spring.batch.job.enabled=false
```

本项目设计为 REST/Vue 手动触发。

## 15. 重复启动 Batch 是否重复插入

Writer 使用姓名和电话判重，重复 CSV 不会重复插入。执行历史仍会增加。
