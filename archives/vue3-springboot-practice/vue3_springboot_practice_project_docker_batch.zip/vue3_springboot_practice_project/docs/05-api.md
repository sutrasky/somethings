# REST API

## 学生列表

```http
GET /api/students
```

搜索：

```http
GET /api/students?query=张
```

## 学生详情

```http
GET /api/students/1
```

## 新增学生

```http
POST /api/students
Content-Type: application/json
```

```json
{
  "name": "王五",
  "age": 22,
  "phone": "13800000003",
  "address": {
    "city": "南京",
    "street": "中山路 300 号"
  },
  "courses": [
    {
      "name": "Spring Boot",
      "score": 95
    }
  ]
}
```

成功：201。

## 更新学生

```http
PUT /api/students/1
```

请求结构与新增相同。

## 删除学生

```http
DELETE /api/students/1
```

成功：204。

## 最近通知

```http
GET /api/notifications/recent
```

## 系统消息广播

```http
POST /api/notifications/system
Content-Type: application/json
```

```json
{
  "title": "系统通知",
  "content": "即将进行系统维护",
  "sender": "管理员"
}
```

成功后消息发送到：

```text
/topic/system
```

## Dashboard

```http
GET /api/dashboard
```

返回学生数、课程数、平均年龄、最近 Batch 执行和最近通知。

## Batch Job 元数据

```http
GET /api/batch/jobs
```

## 启动学生 CSV 导入

```http
POST /api/batch/student-import
```

## Batch 执行历史

```http
GET /api/batch/executions?limit=10
```

## 单次 Batch 执行

```http
GET /api/batch/executions/{id}
```

## 校验错误

```json
{
  "message": "请求校验失败",
  "errors": {
    "name": "姓名不能为空",
    "address.city": "城市不能为空",
    "courses[0].score": "成绩不能大于 100"
  },
  "timestamp": "2026-11-09T20:00:00"
}
```
