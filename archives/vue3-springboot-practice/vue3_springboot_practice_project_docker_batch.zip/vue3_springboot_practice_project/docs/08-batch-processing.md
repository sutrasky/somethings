# Spring Batch 6 学生导入

## 1. Job 组成

```text
Job: studentImportJob
  └── Step: studentImportStep
        ├── FlatFileItemReader<StudentCsvRow>
        ├── StudentImportProcessor
        └── StudentImportWriter
```

Chunk 大小：

```text
5
```

## 2. CSV

文件：

```text
backend/src/main/resources/batch/students-import.csv
```

字段：

```text
name
age
phone
city
street
course1
course1Score
course2
course2Score
```

示例：

```csv
批量导入-赵六,23,13900001111,成都,高新区天府大道 1 号,Spring Batch,91,MySQL,87
```

CSV 中的字段不能包含英文逗号，否则会破坏简单分隔解析。

## 3. Reader

```java
new FlatFileItemReaderBuilder<StudentCsvRow>()
    .name("studentCsvReader")
    .resource(resource)
    .linesToSkip(1)
    .delimited()
    .names("name", "age", ...)
    .fieldSetMapper(...)
    .build();
```

Reader 读取一行，转换成 `StudentCsvRow`。

## 4. Processor

`StudentImportProcessor`：

1. 把 CSV Row 转成 `StudentRequest`。
2. 组合地址对象。
3. 组合课程数组。
4. 使用 Jakarta Validator 校验。
5. 校验失败时终止 Job 并记录异常。

## 5. Writer

`StudentImportWriter`：

1. 检查姓名和电话是否已存在。
2. 重复数据跳过。
3. 新数据调用 `StudentService.create`。

所以 Job 可以重复运行。

## 6. REST 启动

```http
POST /api/batch/student-import
```

响应：

```json
{
  "executionId": 1,
  "jobName": "studentImportJob",
  "status": "COMPLETED",
  "exitCode": "COMPLETED",
  "startTime": "2026-11-19T08:38:10",
  "endTime": "2026-11-19T08:38:11",
  "readCount": 3,
  "writeCount": 3,
  "commitCount": 1,
  "failureMessage": null
}
```

历史：

```http
GET /api/batch/executions?limit=10
```

单次：

```http
GET /api/batch/executions/1
```

## 7. Job 参数

每次启动自动加入：

```text
run.id = System.nanoTime()
```

JobParameters 是 JobInstance 的身份的一部分，因此相同 Job 可以生成多个实例。

## 8. MySQL 验证

```powershell
docker exec student-mysql mysql -uroot -proot -e "
USE student_db;
SELECT ID, JOB_NAME FROM BATCH_JOB_INSTANCE;
SELECT JOB_EXECUTION_ID, STATUS, EXIT_CODE FROM BATCH_JOB_EXECUTION;
SELECT STEP_EXECUTION_ID, READ_COUNT, WRITE_COUNT, COMMIT_COUNT FROM BATCH_STEP_EXECUTION;
"
```

## 9. 重复执行验证

第一次：

```text
读取 3
写入 3
学生总数增加 3
```

第二次：

```text
读取 3
写入步骤仍执行 3 条
实际插入 0 条
学生总数不增加
```

## 10. 失败处理

如果 CSV 数据未通过校验：

- Job 状态为 `FAILED`。
- `failureMessage` 返回原因。
- Batch 元数据保留失败记录。
- 修复 CSV 后再次触发新 execution。

当前示例是入门实现，生产项目可继续增加：

- SkipPolicy
- RetryPolicy
- JobParameters 文件路径
- 上传 CSV 后动态启动
- 异步 JobLauncher
- 失败后 restart
- Step 监听器和指标
