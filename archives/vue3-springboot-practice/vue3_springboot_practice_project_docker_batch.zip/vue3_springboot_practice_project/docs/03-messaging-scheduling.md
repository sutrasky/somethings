# Spring Messaging、STOMP 与 Scheduling

## 1. 四个概念

### Spring Messaging

提供统一的消息模型：

- Message：消息正文 + Headers。
- Destination：消息目的地。
- Handler：消息处理函数。
- Channel：内部消息通道。

### WebSocket

浏览器与服务器之间的双向长连接。

### STOMP

运行在 WebSocket 之上的简单文本消息协议。常用帧：

- `CONNECT`
- `SUBSCRIBE`
- `SEND`
- `MESSAGE`
- `DISCONNECT`

### Message Broker

本项目使用 Spring 的 `SimpleBroker`，负责把消息转发给 Topic 订阅者。

## 2. 连接建立

Vue：

```js
const client = new Client({
  brokerURL: "ws://localhost:5173/ws",
  reconnectDelay: 3000
});
client.activate();
```

Spring：

```java
registry.addEndpoint("/ws");
registry.enableSimpleBroker("/topic", "/queue");
registry.setApplicationDestinationPrefixes("/app");
```

## 3. 前端发送、后端接收

目的地：

```text
/app/notifications/send
```

Spring：

```java
@MessageMapping("/notifications/send")
@SendTo("/topic/notifications")
public NotificationMessage receiveFromClient(
        @Valid NotificationRequest request) {
    return notificationService.fromClient(request);
}
```

调用链：

```mermaid
sequenceDiagram
    participant V as Vue
    participant S as Spring Messaging
    participant H as @MessageMapping
    participant T as /topic/notifications

    V->>S: SEND /app/notifications/send
    S->>H: 转换 JSON 并调用方法
    H->>H: 校验、保存历史
    H-->>T: @SendTo 返回值
    T-->>V: MESSAGE
```

## 4. 订阅初始化

Vue：

```js
client.subscribe("/app/notifications/init", (frame) => {
  const history = JSON.parse(frame.body);
});
```

Spring：

```java
@SubscribeMapping("/notifications/init")
public List<NotificationMessage> initialNotifications() {
    return notificationService.recent();
}
```

与普通 `@MessageMapping` 的区别：

- `@SubscribeMapping` 在 SUBSCRIBE 时执行一次。
- 返回值只回复当前订阅，不广播给所有订阅者。

## 5. SimpMessagingTemplate

REST 主动广播：

```java
messagingTemplate.convertAndSend("/topic/system", message);
```

定时广播：

```java
@Scheduled(fixedRateString = "${practice.scheduling.interval-ms:10000}")
public void publishScheduledNotification() {
    NotificationMessage message =
        notificationService.scheduled("...");
    messagingTemplate.convertAndSend("/topic/notifications", message);
}
```

## 6. 三个具体场景

### 定时消息推送

- 每 10 秒执行。
- 目的地 `/topic/notifications`。
- 类型 `SCHEDULE`。

### 前端发送、后端接收

- 目的地 `/app/notifications/send`。
- `@MessageMapping` 接收。
- `@SendTo` 广播给所有订阅者。

### 后端主动广播

- 来源：REST `/api/notifications/system`。
- 通过 `SimpMessagingTemplate` 推送到 `/topic/system`。

## 7. `@EnableScheduling`

启动类：

```java
@EnableScheduling
@SpringBootApplication
public class StudentPracticeApplication {
}
```

没有 `@EnableScheduling`，`@Scheduled` 方法不会自动执行。

## 8. 为什么使用 `fixedRate`

```java
@Scheduled(
  fixedRateString = "${practice.scheduling.interval-ms:10000}",
  initialDelayString = "${practice.scheduling.initial-delay-ms:5000}")
```

- `fixedRate`：按计划开始时间计算频率。
- `fixedDelay`：上一次执行完再等待。

当前任务只创建并发送消息，执行时间很短，因此 `fixedRate` 合适。

## 9. 消息显示链路

```text
Scheduled Publisher
  -> NotificationService
  -> SimpMessagingTemplate
  -> SimpleBroker
  -> Vue client subscription
  -> addMessages()
  -> reactive messages
  -> NotificationsView 更新
```
