# 启动与目录说明

## 1. 三个运行部分

```text
MySQL 8.4 Docker  :3306
Spring Boot       :8080
Vue 3 + Vite      :5173
```

开发时访问 5173。生产构建后访问 8080。

## 2. Docker MySQL

启动：

```powershell
docker compose up -d
```

查看：

```powershell
docker compose ps
```

健康日志：

```powershell
docker compose logs -f mysql
```

连接参数：

```text
Host: localhost
Port: 3306
Database: student_db
User: root
Password: root
```

## 3. Eclipse

导入 `backend` 为 Maven 项目。

启动类：

```text
backend/src/main/java/com/example/practice/StudentPracticeApplication.java
```

运行方式：

```text
Run As -> Java Application
```

如果启动时报数据库连接失败：

1. `docker compose ps` 确认 healthy。
2. 检查 3306 是否被本机 MySQL 占用。
3. 检查 `backend/src/main/resources/application.properties`。

## 4. Vue

```powershell
cd frontend
npm install
npm run dev
```

打开：

```text
http://localhost:5173
```

Vite 代理：

```text
/api -> http://localhost:8080
/ws  -> ws://localhost:8080
```

## 5. 生产构建

```powershell
cd frontend
npm run build
```

输出：

```text
backend/src/main/resources/static/
```

重新启动 Spring Boot 后访问 8080。

## 6. 数据目录

MySQL 数据保存在：

```text
project-root/data/
```

`docker compose down` 不会删除它。

不要通过删除 `data/` 来停止 MySQL，除非明确准备清空全部数据库数据。

## 7. `.gitignore`

```text
data/*
!data/.gitkeep
```

这保证真实 MySQL 文件不会被提交，但空目录可以被 Git 保留。
