# Vue 3 + Spring Boot 入门实战教程

## 从前后端传值、复杂对象、WebSocket 主动推送到 Vue Router 路由

> **适合读者：** 初学者、课堂教学、实训入门\
> **项目目标：** 搭建一个简单的学生管理系统，学习 Vue 3 与 Spring Boot
> 如何通过 HTTP 交换复杂对象，如何通过 WebSocket
> 接收后端主动推送，以及如何使用 Vue Router 切换页面。

------------------------------------------------------------------------

## 学完你将掌握什么？

-   理解前端、后端、HTTP、JSON 和 API 的关系。
-   使用 Vue 3 表单提交嵌套对象和对象数组。
-   使用 Spring Boot 的 `@RequestBody` 将 JSON 转成 Java 对象。
-   让后端返回 JSON，并在 Vue 页面中显示。
-   使用 WebSocket 实现后端主动推送通知。
-   使用 Vue Router 配置页面地址和页面跳转。
-   使用浏览器开发者工具检查请求和响应。

## 目录

1.  [一、整体原理](#一整体原理)
2.  [二、复杂对象如何传递](#二复杂对象如何传递)
3.  [三、创建 Spring Boot 后端](#三创建-spring-boot-后端)
4.  [四、创建 Vue 3 前端](#四创建-vue-3-前端)
5.  [五、Vue Router 页面路由](#五vue-router-页面路由)
6.  [六、运行项目与验证](#六运行项目与验证)
7.  [七、路由参数与业务数据的区别](#七路由参数与业务数据的区别)
8.  [八、常见错误排查](#八常见错误排查)
9.  [九、练习题](#九练习题)

------------------------------------------------------------------------

## 一、整体原理

### 1.1 前端和后端分别做什么？

-   **Vue 3 前端：** 展示页面、收集用户输入、发起请求、显示返回结果。
-   **Spring Boot 后端：**
    接收请求、执行业务逻辑、验证数据、访问数据库或其他服务、返回结果。
-   **数据库：** 长期保存数据。本教程先使用内存列表演示，不接入数据库。
-   **HTTP：** 前端与后端交换请求和响应的常见协议。
-   **JSON：** 前后端之间常用的数据格式。
-   **API 接口：** 后端提供给前端调用的入口，例如 `POST /api/students`。

### 1.2 两种通信方式

**方式 A：HTTP 请求 / 响应**

``` text
用户填写表单
  ↓
Vue 3 生成 JavaScript 对象
  ↓
JSON.stringify() 转成 JSON 字符串
  ↓
浏览器通过 HTTP 发送请求
  ↓
Spring Boot 收到请求
  ↓
@RequestBody 将 JSON 转为 Java 对象
  ↓
后端处理业务
  ↓
Spring Boot 将返回对象转为 JSON
  ↓
Vue 使用 response.json() 解析响应
  ↓
更新响应式变量，页面显示结果
```

**方式 B：WebSocket 主动推送**

``` text
Vue 与 Spring Boot 建立 WebSocket 连接
  ↓
连接保持打开
  ↓
后端产生一条新消息
  ↓
后端通过已有连接推送消息
  ↓
Vue 的 socket.onmessage 收到消息
  ↓
更新页面
```

普通 HTTP 通常由前端发起请求；WebSocket
建立连接后，双方都可以发送消息。因此，实时通知、在线状态、实时监控等场景可以使用
WebSocket。

------------------------------------------------------------------------

## 二、复杂对象如何传递

本教程使用"学生管理"作为例子。前端一次提交学生的基本信息、地址和课程列表。

### 2.1 前端发送的 JSON 示例

``` json
{
  "name": "张三",
  "age": 20,
  "address": {
    "city": "上海",
    "street": "人民路100号"
  },
  "courses": [
    {
      "name": "Java",
      "score": 90
    },
    {
      "name": "数据库",
      "score": 85
    }
  ]
}
```

这个对象包含：

-   普通字段：`name`、`age`
-   嵌套对象：`address`
-   对象数组：`courses`

前端不需要每个字段单独发送一次请求，而是将整个对象放在一次 HTTP
请求的请求正文中。

### 2.2 数据对应关系

  JSON 字段            Java 类型        说明
  -------------------- ---------------- --------------
  `name`               `String`         学生姓名
  `age`                `Integer`        年龄
  `address`            `Address`        嵌套地址对象
  `courses`            `List<Course>`   课程对象列表
  `courses[i].score`   `Integer`        课程成绩

默认情况下，JSON 字段名称与 Java 对象属性对应时，Spring 的 JSON
转换机制可以自动完成转换。前后端字段名、类型和数据结构需要保持一致。

------------------------------------------------------------------------

## 三、创建 Spring Boot 后端

### 3.1 创建项目

使用 [Spring Initializr](https://start.spring.io/) 或 IntelliJ IDEA
创建项目：

-   Project：Maven
-   Language：Java
-   Java：17 或更高版本
-   Spring Boot：选择创建工具提供的兼容稳定版本
-   Dependencies：Spring Web、WebSocket

本教程代码面向 Spring Boot 3.x、Java 17+。

### 3.2 项目结构

``` text
student-server/
├── pom.xml
└── src/main/
    ├── java/com/example/student/
    │   ├── StudentApplication.java
    │   ├── config/
    │   │   └── WebSocketConfig.java
    │   ├── controller/
    │   │   └── StudentController.java
    │   ├── dto/
    │   │   ├── StudentRequest.java
    │   │   └── StudentResponse.java
    │   └── service/
    │       └── StudentService.java
    └── resources/
        └── application.properties
```

> **注意：** 以下每个 Java 文件都应放在对应目录中，`package`
> 声明必须与目录一致。

### 3.3 `pom.xml`

如果通过 Spring Initializr 创建了项目，可以保留生成的
`pom.xml`，并确认包含以下两个依赖：

``` xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-websocket</artifactId>
</dependency>
```

不要将依赖片段直接覆盖整个 `pom.xml`；它们应放在 `<dependencies>`
标签内部。Spring Initializr 会生成完整的 Maven 项目文件。

### 3.4 启动类：`StudentApplication.java`

``` java
package com.example.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class StudentApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentApplication.class, args);
    }
}
```

`@SpringBootApplication` 是 Spring Boot
应用的主要启动注解。`@EnableScheduling` 启用后续的定时推送任务。

### 3.5 请求对象：`dto/StudentRequest.java`

``` java
package com.example.student.dto;

import java.util.List;

public record StudentRequest(
        String name,
        Integer age,
        Address address,
        List<Course> courses
) {
    public record Address(
            String city,
            String street
    ) {}

    public record Course(
            String name,
            Integer score
    ) {}
}
```

这里使用 Java 17 的 `record` 简化数据类。可以通过
`request.name()`、`request.address().city()` 等方法读取字段。

### 3.6 响应对象：`dto/StudentResponse.java`

``` java
package com.example.student.dto;

import java.util.List;

public record StudentResponse(
        Long id,
        String name,
        Integer age,
        StudentRequest.Address address,
        List<StudentRequest.Course> courses
) {}
```

响应对象比请求对象多一个
`id`，用于演示后端生成并返回额外字段。真实项目中，请求 DTO 和响应 DTO
可以根据业务需求独立设计。

### 3.7 业务层：`service/StudentService.java`

``` java
package com.example.student.service;

import com.example.student.dto.StudentRequest;
import com.example.student.dto.StudentResponse;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class StudentService {

    private final List<StudentResponse> students =
            new ArrayList<>();

    private final AtomicLong idGenerator =
            new AtomicLong(1);

    public synchronized StudentResponse create(
            StudentRequest request) {

        if (request.name() == null ||
                request.name().isBlank()) {
            throw new IllegalArgumentException(
                    "学生姓名不能为空");
        }

        StudentResponse student = new StudentResponse(
                idGenerator.getAndIncrement(),
                request.name(),
                request.age(),
                request.address(),
                request.courses()
        );

        students.add(student);
        return student;
    }

    public synchronized List<StudentResponse> findAll() {
        return List.copyOf(students);
    }
}
```

这段业务代码完成：

1.  检查姓名是否为空。
2.  生成 ID。
3.  创建响应对象。
4.  将学生放入内存列表。
5.  返回新创建的学生。

这里没有使用数据库。应用重启后，内存中的学生数据会丢失。

### 3.8 HTTP 控制器：`controller/StudentController.java`

``` java
package com.example.student.controller;

import com.example.student.dto.StudentRequest;
import com.example.student.dto.StudentResponse;
import com.example.student.service.StudentService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "http://localhost:5173")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping
    public ResponseEntity<StudentResponse> create(
            @RequestBody StudentRequest request) {

        StudentResponse student =
                studentService.create(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(student);
    }

    @GetMapping
    public List<StudentResponse> findAll() {
        return studentService.findAll();
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleBadRequest(
            IllegalArgumentException exception) {

        return ResponseEntity
                .badRequest()
                .body(Map.of(
                        "message",
                        exception.getMessage()
                ));
    }
}
```

#### 关键注解解释

  注解                                 作用
  ------------------------------------ --------------------------------------
  `@RestController`                    定义处理 HTTP 请求并返回数据的控制器
  `@RequestMapping("/api/students")`   设置统一的接口路径前缀
  `@PostMapping`                       处理 POST 请求
  `@GetMapping`                        处理 GET 请求
  `@RequestBody`                       将请求正文中的 JSON 转成 Java 对象
  `@CrossOrigin`                       允许指定前端源进行跨域访问

两个接口：

  方法   URL               用途           成功状态
  ------ ----------------- -------------- ---------------
  POST   `/api/students`   创建学生       `201 Created`
  GET    `/api/students`   获取学生列表   `200 OK`

当浏览器发出 POST 请求时，Spring 会读取 JSON，将它转换为
`StudentRequest`，再将对象交给 `StudentService`。返回的
`StudentResponse` 会被转换成 JSON 放入 HTTP 响应正文。

### 3.9 WebSocket 配置：`config/WebSocketConfig.java`

这个例子使用原生 WebSocket，不额外引入 STOMP 协议。

``` java
package com.example.student.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final Set<WebSocketSession> sessions =
            ConcurrentHashMap.newKeySet();

    @Override
    public void registerWebSocketHandlers(
            WebSocketHandlerRegistry registry) {

        registry.addHandler(notificationHandler(), "/ws/notifications")
                .setAllowedOrigins("http://localhost:5173");
    }

    @Bean
    public TextWebSocketHandler notificationHandler() {
        return new TextWebSocketHandler() {

            @Override
            public void afterConnectionEstablished(
                    WebSocketSession session) {
                sessions.add(session);
                System.out.println(
                        "前端已连接：" + session.getId());
            }

            @Override
            public void afterConnectionClosed(
                    WebSocketSession session,
                    CloseStatus status) {
                sessions.remove(session);
                System.out.println(
                        "前端已断开：" + session.getId());
            }
        };
    }

    @Scheduled(fixedRate = 10000)
    public void pushNotification() {
        String message =
                "后端主动通知：" + LocalDateTime.now();

        for (WebSocketSession session : sessions) {
            if (!session.isOpen()) {
                sessions.remove(session);
                continue;
            }

            try {
                synchronized (session) {
                    if (session.isOpen()) {
                        session.sendMessage(
                                new TextMessage(message));
                    }
                }
            } catch (IOException exception) {
                sessions.remove(session);
                System.err.println(
                        "推送失败：" + exception.getMessage());
            }
        }
    }
}
```

#### WebSocket 的工作过程

1.  前端访问 `/ws/notifications` 并建立连接。
2.  后端将连接保存到 `sessions` 集合。
3.  定时任务大约每 10 秒执行一次。
4.  后端向所有在线连接发送消息。
5.  前端收到消息后更新页面。
6.  前端离开通知页面时关闭连接，后端移除已关闭的连接。

生产环境还需要考虑身份验证、连接权限、心跳、断线重连、消息可靠性和多实例广播等问题。

### 3.10 后端配置：`application.properties`

``` properties
server.port=8080
```

------------------------------------------------------------------------

## 四、创建 Vue 3 前端

### 4.1 创建项目并安装依赖

``` bash
npm create vue@latest student-client
cd student-client
npm install
npm install vue-router@4
npm run dev
```

如果创建项目时已经选择安装 Vue Router，则无需重复安装。

### 4.2 前端项目结构

``` text
student-client/
├── src/
│   ├── api/
│   │   └── students.js
│   ├── router/
│   │   └── index.js
│   ├── views/
│   │   ├── StudentsView.vue
│   │   └── NotificationsView.vue
│   ├── App.vue
│   └── main.js
├── package.json
└── vite.config.js
```

### 4.3 API 模块：`src/api/students.js`

``` javascript
const BASE_URL = 'http://localhost:8080/api/students'

async function request(url, options = {}) {
  const response = await fetch(url, options)

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}))
    throw new Error(
      errorData.message || `请求失败：${response.status}`
    )
  }

  return response.json()
}

export function createStudent(student) {
  return request(BASE_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(student)
  })
}

export function getStudents() {
  return request(BASE_URL)
}
```

#### 最重要的两行

``` javascript
body: JSON.stringify(student)
```

将 JavaScript 对象转为 JSON 字符串，作为 HTTP 请求正文。

``` javascript
return response.json()
```

读取响应正文，并将 JSON 解析为 JavaScript 对象。

`fetch()` 返回的是一个 Promise；`await`
会等待该异步操作完成。网络错误和非成功 HTTP 状态码应分别处理。本教程的
`request()` 对非 2xx 响应进行了检查。

### 4.4 学生管理页：`src/views/StudentsView.vue`

``` vue
<script setup>
import { reactive, ref, onMounted } from 'vue'
import { createStudent, getStudents } from '../api/students'

const form = reactive({
  name: '张三',
  age: 20,
  address: {
    city: '上海',
    street: '人民路100号'
  },
  courses: [
    { name: 'Java', score: 90 },
    { name: '数据库', score: 85 }
  ]
})

const students = ref([])
const loading = ref(false)
const message = ref('')

async function loadStudents() {
  try {
    students.value = await getStudents()
  } catch (error) {
    message.value = error.message
  }
}

async function submitStudent() {
  loading.value = true
  message.value = ''

  try {
    const created = await createStudent(form)
    message.value = `创建成功！学生 ID：${created.id}`
    await loadStudents()
  } catch (error) {
    message.value = `创建失败：${error.message}`
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  loadStudents()
})
</script>

<template>
  <main class="page">
    <h1>学生管理</h1>

    <form @submit.prevent="submitStudent">
      <h2>基本信息</h2>

      <label>
        姓名
        <input v-model="form.name" required />
      </label>

      <label>
        年龄
        <input
          v-model.number="form.age"
          type="number"
          min="1"
          required
        />
      </label>

      <h2>地址信息</h2>

      <label>
        城市
        <input v-model="form.address.city" />
      </label>

      <label>
        街道
        <input v-model="form.address.street" />
      </label>

      <h2>课程信息</h2>

      <div
        v-for="(course, index) in form.courses"
        :key="index"
        class="course"
      >
        <label>
          课程名称
          <input v-model="course.name" />
        </label>

        <label>
          分数
          <input
            v-model.number="course.score"
            type="number"
            min="0"
            max="100"
          />
        </label>
      </div>

      <button type="submit" :disabled="loading">
        {{ loading ? '提交中...' : '提交整个学生对象' }}
      </button>
    </form>

    <p v-if="message" role="status">{{ message }}</p>

    <h2>学生列表</h2>

    <p v-if="students.length === 0">暂无学生数据</p>

    <article
      v-for="student in students"
      :key="student.id"
      class="student"
    >
      <h3>{{ student.name }}（ID：{{ student.id }}）</h3>
      <p>年龄：{{ student.age }}</p>
      <p>
        地址：{{ student.address.city }}
        {{ student.address.street }}
      </p>

      <ul>
        <li
          v-for="(course, index) in student.courses"
          :key="index"
        >
          {{ course.name }}：{{ course.score }} 分
        </li>
      </ul>
    </article>
  </main>
</template>

<style scoped>
.page {
  max-width: 720px;
  margin: 30px auto;
  padding: 20px;
  font-family: sans-serif;
}

form {
  display: grid;
  gap: 14px;
}

label {
  display: grid;
  gap: 6px;
}

input {
  padding: 9px;
}

.course,
.student {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 12px;
  margin-bottom: 12px;
}

button {
  padding: 12px;
  cursor: pointer;
}
</style>
```

#### 理解前端提交的核心过程

`form` 是一个嵌套的 JavaScript 对象。`v-model`
会将输入内容同步到相应属性中，例如：

``` javascript
form.name
form.address.city
form.courses[0].score
```

点击提交后，代码执行：

``` javascript
const created = await createStudent(form)
```

`createStudent()` 将整个对象交给 API 模块，API 模块再执行
`JSON.stringify(student)`，将整个对象一次性发送给后端。

后端返回带有 `id` 的 JSON，`response.json()` 将它解析成 JavaScript
对象，最后赋给 `created`。

### 4.5 通知页：`src/views/NotificationsView.vue`

``` vue
<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const connectionStatus = ref('正在连接...')
const messages = ref([])

let socket = null

onMounted(() => {
  socket = new WebSocket(
    'ws://localhost:8080/ws/notifications'
  )

  socket.onopen = () => {
    connectionStatus.value = '已连接'
  }

  socket.onmessage = (event) => {
    messages.value.unshift({
      id: Date.now() + Math.random(),
      text: event.data
    })
  }

  socket.onerror = () => {
    connectionStatus.value = '连接发生错误'
  }

  socket.onclose = () => {
    connectionStatus.value = '连接已关闭'
  }
})

onUnmounted(() => {
  if (socket) {
    socket.close()
    socket = null
  }
})
</script>

<template>
  <main class="page">
    <h1>后端实时通知</h1>

    <p>
      WebSocket 状态：
      <strong>{{ connectionStatus }}</strong>
    </p>

    <p>保持连接后，后端可以主动推送消息。</p>

    <h2>收到的通知</h2>

    <p v-if="messages.length === 0">
      等待后端推送消息……
    </p>

    <ul>
      <li v-for="item in messages" :key="item.id">
        {{ item.text }}
      </li>
    </ul>
  </main>
</template>

<style scoped>
.page {
  max-width: 720px;
  margin: 30px auto;
  padding: 20px;
  font-family: sans-serif;
}

li {
  padding: 10px;
  margin-bottom: 8px;
  border: 1px solid #ddd;
  border-radius: 6px;
}
</style>
```

`socket.onmessage` 会在收到服务端消息时执行。把消息插入 `messages`
后，Vue 会自动更新页面。

`onMounted()` 在组件挂载后建立连接；`onUnmounted()`
在组件卸载时关闭连接，避免页面切换后继续保留不需要的连接。

------------------------------------------------------------------------

## 五、Vue Router 页面路由

### 5.1 路由是什么？

Vue Router 是 Vue 官方生态中常用的路由库。它根据浏览器 URL
决定显示哪个组件。

  URL                显示页面
  ------------------ ------------------------
  `/`                自动跳转到 `/students`
  `/students`        学生管理页
  `/notifications`   实时通知页

**路由解决"显示哪个页面"的问题；HTTP 和 WebSocket
解决"如何与后端交换数据"的问题。**

### 5.2 路由文件：`src/router/index.js`

``` javascript
import { createRouter, createWebHistory } from 'vue-router'

import StudentsView from '../views/StudentsView.vue'
import NotificationsView from '../views/NotificationsView.vue'

const routes = [
  {
    path: '/',
    redirect: '/students'
  },
  {
    path: '/students',
    name: 'Students',
    component: StudentsView
  },
  {
    path: '/notifications',
    name: 'Notifications',
    component: NotificationsView
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
```

字段含义：

-   `path`：匹配的 URL 路径。
-   `name`：路由名称，可用于命名导航。
-   `component`：匹配时显示的 Vue 组件。
-   `redirect`：重定向目标。
-   `createWebHistory()`：使用不带 `#` 的 URL 形式。

### 5.3 注册路由：`src/main.js`

``` javascript
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

createApp(App)
  .use(router)
  .mount('#app')
```

`.use(router)` 将路由系统注册到 Vue 应用中。

### 5.4 全局导航：`src/App.vue`

``` vue
<template>
  <div>
    <header class="header">
      <h2>学生管理系统</h2>

      <nav>
        <RouterLink to="/students">学生管理</RouterLink>
        <RouterLink to="/notifications">实时通知</RouterLink>
      </nav>
    </header>

    <RouterView />
  </div>
</template>

<style>
body {
  margin: 0;
  font-family: sans-serif;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 16px 24px;
  border-bottom: 1px solid #ddd;
}

nav {
  display: flex;
  gap: 20px;
}

nav a {
  color: #1769aa;
  text-decoration: none;
}

nav a.router-link-active {
  font-weight: bold;
  text-decoration: underline;
}
</style>
```

-   `<RouterLink to="/students">`：点击后导航到学生管理页。
-   `<RouterView />`：显示当前 URL 对应的页面组件。
-   `router-link-active`：用于设置当前激活链接的样式。

### 5.5 路由参数：查看指定学生

如果增加学生详情页，可以配置：

``` javascript
{
  path: '/students/:id',
  name: 'StudentDetail',
  component: () => import('../views/StudentDetailView.vue')
}
```

访问 `/students/1` 后，可以在详情组件中读取：

``` javascript
import { useRoute } from 'vue-router'

const route = useRoute()
console.log(route.params.id) // "1"
```

这里的 `id`
是字符串。读取路由参数并不会自动查询后端；如果需要学生详情，还需要前端调用对应的
HTTP API，例如
`GET /api/students/1`。本教程后端暂时只实现了创建和列表接口。

### 5.6 查询参数：搜索与分页

例如：

``` text
/students?city=上海&page=2
```

读取方式：

``` javascript
import { useRoute } from 'vue-router'

const route = useRoute()

console.log(route.query.city) // "上海"
console.log(route.query.page) // "2"
```

查询参数常用于搜索词、分页页码、排序方式和筛选条件。

### 5.7 三种传值方式的区别

  方式             适用场景           示例
  ---------------- ------------------ ----------------------
  路由参数         标识页面或资源     `/students/1`
  HTTP JSON 正文   提交复杂业务对象   `POST /api/students`
  WebSocket 消息   实时双向消息       后端推送通知

路由参数不会自动传给 Spring Boot。需要后端数据时，前端仍然要发送 HTTP
请求；需要实时推送时，可以使用 WebSocket。

------------------------------------------------------------------------

## 六、运行项目与验证

### 6.1 启动后端

在 IntelliJ IDEA 中运行 `StudentApplication.java`。默认后端地址为：

``` text
http://localhost:8080
```

### 6.2 启动前端

进入 `student-client` 目录：

``` bash
npm install
npm run dev
```

访问终端显示的地址，通常是：

``` text
http://localhost:5173
```

### 6.3 测试复杂对象

1.  进入 `/students`。
2.  修改姓名、地址或课程成绩。
3.  点击"提交整个学生对象"。
4.  打开浏览器开发者工具（F12）。
5.  选择 Network（网络）面板。
6.  查看 `POST /api/students` 的请求正文和响应正文。

预期请求正文：

``` json
{
  "name": "张三",
  "age": 20,
  "address": {
    "city": "上海",
    "street": "人民路100号"
  },
  "courses": [
    {
      "name": "Java",
      "score": 90
    },
    {
      "name": "数据库",
      "score": 85
    }
  ]
}
```

成功时，响应状态为 `201 Created`，返回对象中会包含后端生成的 `id`。

### 6.4 测试后端主动推送

1.  访问 `/notifications`。
2.  查看页面上的 WebSocket 状态。
3.  等待约 10 秒。
4.  查看是否出现后端推送的通知。

注意：只有在通知页面建立 WebSocket 连接后，浏览器才会收到本示例的消息。

------------------------------------------------------------------------

## 七、路由参数与业务数据的区别

可以用以下方式理解：

-   路由 `/students/1` 表示用户正在访问 ID 为 1 的学生详情页面。
-   HTTP 请求正文中的学生对象用于向后端提交一组业务数据。
-   WebSocket 消息用于在连接建立后实时发送消息。

不要把这三种用途混在一起。路由负责导航；HTTP 负责请求与响应；WebSocket
负责已建立连接上的实时消息。

------------------------------------------------------------------------

## 八、常见错误排查

  --------------------------------------------------------------------------------------------------
  问题                       可能原因                               排查方法
  -------------------------- -------------------------------------- --------------------------------
  `Failed to fetch`          后端未启动、地址错误、跨域或网络问题   检查后端日志、URL 和浏览器
                                                                    Console

  `404 Not Found`            请求路径不匹配                         检查 `/api/students` 和
                                                                    Controller 映射

  `405 Method Not Allowed`   HTTP 方法不匹配                        检查前端使用 GET 还是 POST

  `400 Bad Request`          JSON 格式错误或类型不匹配              查看 Request Payload 和后端日志

  收到的字段为 `null`        字段名或数据结构不匹配                 对照 JSON 和 Java DTO

  WebSocket 连接失败         后端未启动、路径或允许的来源不匹配     检查 `/ws/notifications` 和
                                                                    Console

  路由刷新后出现 404         部署服务器没有配置 history fallback    配置服务器将前端路由请求回退到
                                                                    `index.html`

  刷新后学生列表为空         示例使用内存列表，重启后数据会清空     后续接入数据库
  --------------------------------------------------------------------------------------------------

### 开发环境跨域说明

本示例允许来自 `http://localhost:5173` 的请求。如果 Vite
使用其他端口，必须相应调整后端 CORS 和 WebSocket
的允许来源配置。不要在生产环境中无条件允许所有来源。

------------------------------------------------------------------------

## 九、练习题

### 练习 1：扩展复杂对象

给学生对象增加字段 `phone`：

1.  修改前端 `form`。
2.  修改 `StudentRequest`。
3.  修改 `StudentResponse`。
4.  修改 Service 的对象构造逻辑。
5.  在页面显示手机号。

思考：如果只改前端而不改后端，会发生什么？

### 练习 2：增加课程

在页面增加一个"添加课程"按钮，允许用户新增一门课程。

提示：可以在 Vue 中操作数组：

``` javascript
form.courses.push({
  name: '',
  score: 0
})
```

观察新增课程是否随着整个对象一起发送给后端。

### 练习 3：增加学生详情接口

实现：

``` text
GET /api/students/{id}
```

要求：

-   Service 根据 ID 查询学生。
-   Controller 返回学生对象。
-   前端详情页从路由读取 ID。
-   前端调用接口并显示结果。
-   找不到学生时返回合适的 HTTP 状态码。

### 练习 4：改变主动推送内容

把 WebSocket 推送内容改成 JSON，例如：

``` json
{
  "type": "NOTICE",
  "message": "有一名新学生加入",
  "time": "2026-10-28T10:00:00"
}
```

思考：前端收到字符串后，如何用 `JSON.parse(event.data)` 将它转换成对象？

### 练习 5：接入数据库

将内存中的 `ArrayList` 替换为 MySQL 持久化存储。可以进一步学习 Spring
Data JPA 或 MyBatis。

------------------------------------------------------------------------

## 十、学习总结

掌握以下链路，就掌握了 Vue 3 与 Spring Boot 通信的核心：

``` text
Vue 表单
  ↓
JavaScript 复杂对象
  ↓
JSON.stringify()
  ↓
HTTP POST 请求
  ↓
Spring Boot @RequestBody
  ↓
Java DTO 对象
  ↓
Service 业务处理
  ↓
Controller 返回响应
  ↓
JSON 响应
  ↓
response.json()
  ↓
Vue 响应式变量更新页面
```

后端主动推送则是：

``` text
Vue 创建 WebSocket 连接
  ↓
Spring Boot 保存连接
  ↓
后端发送消息
  ↓
Vue socket.onmessage 接收
  ↓
Vue 更新页面
```

页面路由则是：

``` text
浏览器 URL
  ↓
Vue Router 匹配路由
  ↓
RouterView 显示对应组件
```

### 官方参考资料

-   [Vue 3 官方指南（中文）](https://cn.vuejs.org/guide/)
-   [Vue Router 官方指南（中文）](https://router.vuejs.org/zh/guide/)
-   [Spring Boot
    官方文档](https://docs.spring.io/spring-boot/index.html)
-   [Spring 官方 REST
    服务教程](https://spring.io/guides/gs/rest-service/)
-   [Spring 官方 WebSocket
    教程](https://spring.io/guides/gs/messaging-stomp-websocket)
-   [Spring Initializr](https://start.spring.io/)

> **教师提示：** 建议课堂先运行复杂对象 HTTP 示例，再讲解 Network
> 面板，最后演示 WebSocket
> 和路由。每个阶段都让学生修改一个字段或路径并观察结果，比单纯阅读代码更容易理解。
